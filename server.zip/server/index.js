// const express = require("express");
// const multer = require("multer");
// const cloudinary = require("cloudinary").v2;
// const { CloudinaryStorage } = require("multer-storage-cloudinary");
// const fs = require("fs");
// const http = require("http");
// const path = require("path");
// const ffmpeg = require("fluent-ffmpeg");
// const ffmpegPath = require("ffmpeg-static");
// const FormData = require("form-data");
// const fetch = require("node-fetch"); // If you get ESM issue, use v2: npm install node-fetch@2
// const OpenAI = require("openai");
// const mongoose = require("mongoose");
// const bcrypt = require("bcryptjs");
// const jwt = require("jsonwebtoken");
// const cors = require("cors");
// const helmet = require("helmet");
// const rateLimit = require("express-rate-limit");
// const validator = require("validator");
// const twilio = require("twilio");
// const sgMail = require("@sendgrid/mail");
// const chatRoutes = require("./chat");
// const { Server } = require("socket.io");
// require("dotenv").config();
// const notification = require("./notification");

// const app = express();
// app.use(express.json());

// // Cloudinary config
// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// });

// // Multer storage
// const storage = new CloudinaryStorage({
//   cloudinary,
//   params: { folder: "audio_uploads", resource_type: "auto" },
// });
// const upload = multer({ storage });

// // OpenAI client
// const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// // Predefined questions
// const questionsData = [
//   {
//     id: 1,
//     text: "میری پروفائل کیسے بناؤں؟",
//     response:
//       "پروفائل بنانے کے لیے 'پروفائل' سیکشن میں جائیں، تمام معلومات بھریں اور 'سیو' پر کلک کریں۔",
//   },
//   {
//     id: 2,
//     text: "میں ملازمت کے لیے کیسے درخواست دوں؟",
//     response:
//       "ملازمت کے لیے درخواست دینے کے لیے 'Jobs' میں جائیں، مطلوبہ نوکری منتخب کریں اور 'Apply' پر کلک کریں۔",
//   },
//   {
//     id: 3,
//     text: "میرے قریب کون سے ملز میں کام ہے؟",
//     response:
//       "قریبی ملز دیکھنے کے لیے 'Nearby Jobs' سیکشن کھولیں اور دستیاب مواقع دیکھیں۔",
//   },
//   {
//     id: 4,
//     text: "میں اپنی مہارتیں کیسے اپ ڈیٹ کروں؟",
//     response:
//       "مہارتیں اپ ڈیٹ کرنے کے لیے 'Skills' سیکشن میں جائیں، نئی مہارتیں شامل کریں اور 'Save' کریں۔",
//   },
//   {
//     id: 5,
//     text: "کیا میں کسی ٹھیکیدار کی ٹیم میں شامل ہو سکتا ہوں؟",
//     response:
//       "جی ہاں، 'Contractors' میں جائیں اور ٹیم میں شامل ہونے کے لیے درخواست دیں۔",
//   },
//   {
//     id: 6,
//     text: "نئی نوکریوں کے بارے میں اطلاع کیسے ملے گی؟",
//     response:
//       "نئی نوکریوں کی اطلاع کے لیے 'Notifications' آن کریں یا ایپ کی اپ ڈیٹس دیکھیں۔",
//   },
//   {
//     id: 7,
//     text: "میں اپنی موجودگی کب تک ظاہر کروں؟",
//     response:
//       "موجودگی ظاہر کرنے کے لیے 'Attendance' سیکشن میں جائیں اور اپنی موجودگی اپ ڈیٹ کریں۔",
//   },
//   {
//     id: 8,
//     text: "میرے کام کی تنخواہ کب ملے گی؟",
//     response:
//       "تنخواہ کی تاریخ 'Salary' سیکشن میں دیکھیں یا اپنے کمپنی کے شیڈول کے مطابق۔",
//   },
//   {
//     id: 9,
//     text: "میں کس طرح ڈیجیٹل معاہدہ دیکھ سکتا ہوں؟",
//     response:
//       "ڈیجیٹل معاہدہ دیکھنے کے لیے 'Contracts' سیکشن میں جائیں اور متعلقہ معاہدہ کھولیں۔",
//   },
//   {
//     id: 10,
//     text: "میں اپنی ریٹنگ کیسے دیکھ سکتا ہوں؟",
//     response: "اپنی ریٹنگ دیکھنے کے لیے 'Profile' یا 'Ratings' سیکشن کھولیں۔",
//   },
//   {
//     id: 11,
//     text: "کیا میں نوکری چھوڑنا چاہوں تو کیسے کروں؟",
//     response:
//       "نوکری چھوڑنے کے لیے 'Jobs' سیکشن میں جائیں اور 'Resign' آپشن استعمال کریں۔",
//   },
//   {
//     id: 12,
//     text: "میں کس طرح اپنی جگہ کا پتہ درست کر سکتا ہوں؟",
//     response:
//       "اپنی جگہ درست کرنے کے لیے 'Settings' > 'Location' میں جائیں اور درست پتہ درج کریں۔",
//   },
//   {
//     id: 13,
//     text: "میں کس طرح زیادہ قریبی ملازمت تلاش کر سکتا ہوں؟",
//     response:
//       "قریبی ملازمتیں تلاش کرنے کے لیے 'Nearby Jobs' سیکشن میں فلٹرز استعمال کریں۔",
//   },
//   {
//     id: 14,
//     text: "میں اپنی پروفائل میں تصویریں کیسے ڈالوں؟",
//     response:
//       "پروفائل میں تصاویر شامل کرنے کے لیے 'Profile' > 'Edit' > 'Upload Photo' پر جائیں۔",
//   },
//   {
//     id: 15,
//     text: "کیا میں کسی دوسرے مل میں بھی کام کر سکتا ہوں؟",
//     response:
//       "جی ہاں، 'Jobs' سیکشن میں مختلف ملز کے مواقع دیکھیں اور درخواست دیں۔",
//   },
//   {
//     id: 16,
//     text: "میں اپنی دستیابی کب تبدیل کر سکتا ہوں؟",
//     response:
//       "اپنی دستیابی تبدیل کرنے کے لیے 'Availability' سیکشن میں جائیں اور نئی تاریخ یا وقت سیٹ کریں۔",
//   },
//   {
//     id: 17,
//     text: "نوکری کے بارے میں نوٹیفکیشن کیسے آن کریں؟",
//     response:
//       "نوٹیفکیشن آن کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور متعلقہ آپشن آن کریں۔",
//   },
//   {
//     id: 18,
//     text: "میں ٹھیکیدار کے ساتھ کیسے رابطہ کروں؟",
//     response:
//       "ٹھیکیدار سے رابطہ کرنے کے لیے 'Contractors' میں جائیں اور 'Contact' آپشن استعمال کریں۔",
//   },
//   {
//     id: 19,
//     text: "میری کام کی ریکارڈ کیسے دیکھیں؟",
//     response:
//       "کام کی ریکارڈ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن کھولیں۔",
//   },
//   {
//     id: 20,
//     text: "کیا میں اپنی تنخواہ کا حساب خود دیکھ سکتا ہوں؟",
//     response:
//       "جی ہاں، 'Salary' سیکشن میں جائیں اور 'Salary Calculator' استعمال کریں۔",
//   },
//   {
//     id: 21,
//     text: "میں نئی مہارتیں کیسے سیکھ سکتا ہوں؟",
//     response:
//       "نئی مہارتیں سیکھنے کے لیے 'Learning' یا 'Skills' سیکشن میں دستیاب کورسز دیکھیں۔",
//   },
//   {
//     id: 22,
//     text: "میں کسی شکایت یا مسئلے کی اطلاع کیسے دوں؟",
//     response:
//       "شکایت یا مسئلے کی اطلاع دینے کے لیے 'Support' > 'Report Issue' استعمال کریں۔",
//   },
//   {
//     id: 23,
//     text: "میں کون سے ملز کے ساتھ کام کر چکا ہوں دیکھ سکتا ہوں؟",
//     response:
//       "اپنے کام کیے گئے ملز دیکھنے کے لیے 'Work History' یا 'Jobs Completed' سیکشن کھولیں۔",
//   },
//   {
//     id: 24,
//     text: "کیا میں کسی دوست کو بھی ایپ پر لاؤ سکتا ہوں؟",
//     response:
//       "جی ہاں، 'Invite Friends' آپشن استعمال کریں اور دوست کو ایپ پر مدعو کریں۔",
//   },
//   {
//     id: 25,
//     text: "میں اپنے کام کی تاریخ کیسے دیکھوں؟",
//     response:
//       "اپنے کام کی تاریخ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن استعمال کریں۔",
//   },
//   {
//     id: 26,
//     text: "کیا میں ادائیگی کے طریقے بدل سکتا ہوں؟",
//     response:
//       "ادائیگی کے طریقے بدلنے کے لیے 'Settings' > 'Payment Methods' میں جائیں اور نیا طریقہ منتخب کریں۔",
//   },
//   {
//     id: 27,
//     text: "میں اپنی پروفائل بند کیسے کروں؟",
//     response:
//       "پروفائل بند کرنے کے لیے 'Profile' > 'Settings' > 'Deactivate Account' استعمال کریں۔",
//   },
//   {
//     id: 28,
//     text: "میں نئی جگہ پر کیسے کام تلاش کروں؟",
//     response:
//       "نئی جگہ پر کام تلاش کرنے کے لیے 'Jobs' سیکشن میں فلٹرز کے ذریعے مقام منتخب کریں۔",
//   },
//   {
//     id: 29,
//     text: "میں کام کے اوقات کیسے دیکھ سکتا ہوں؟",
//     response:
//       "کام کے اوقات دیکھنے کے لیے 'Work Schedule' یا 'Shifts' سیکشن کھولیں۔",
//   },
//   {
//     id: 30,
//     text: "میں کس طرح اپنے کام کی درجہ بندی بڑھا سکتا ہوں؟",
//     response:
//       "کام کی درجہ بندی بڑھانے کے لیے اچھا کام کریں، ریویوز حاصل کریں اور 'Ratings' اپ ڈیٹ کریں۔",
//   },
//   {
//     id: 31,
//     text: "ایپ کو کیسے چلائیں؟",
//     response:
//       "ایپ کو چلانے کے لیے اسے انسٹال کریں، لاگ ان کریں اور مین مینو سے اپنے فیچرز استعمال کریں۔",
//   },
//   {
//     id: 32,
//     text: "میں اپنا پاسورڈ کیسے بدل سکتا ہوں؟",
//     response: "پاسورڈ بدلنے کے لیے 'Settings' > 'Change Password' میں جائیں۔",
//   },
//   {
//     id: 33,
//     text: "میں ایپ میں نوٹیفکیشن کیسے آن کروں؟",
//     response:
//       "نوٹیفکیشن آن کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور مطلوبہ آپشن آن کریں۔",
//   },
//   {
//     id: 34,
//     text: "میں ایپ میں نئی نوکری کیسے دیکھوں؟",
//     response:
//       "نئی نوکری دیکھنے کے لیے 'Jobs' سیکشن کھولیں اور فلٹرز استعمال کریں۔",
//   },
//   {
//     id: 35,
//     text: "میں ایپ میں اپنی پروفائل اپ ڈیٹ کیسے کروں؟",
//     response:
//       "پروفائل اپ ڈیٹ کرنے کے لیے 'Profile' > 'Edit' میں جائیں اور معلومات بدلیں۔",
//   },
//   {
//     id: 36,
//     text: "میں ایپ پر اپنے کام کی رپورٹ کیسے دیکھوں؟",
//     response:
//       "کام کی رپورٹ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن استعمال کریں۔",
//   },
//   {
//     id: 37,
//     text: "میں ایپ میں کسی ٹھیکیدار سے کیسے رابطہ کروں؟",
//     response:
//       "ٹھیکیدار سے رابطہ کرنے کے لیے 'Contractors' > 'Contact' استعمال کریں۔",
//   },
//   {
//     id: 38,
//     text: "میں ایپ پر نوکری چھوڑنے کا طریقہ کیا ہے؟",
//     response: "نوکری چھوڑنے کے لیے 'Jobs' میں جائیں اور 'Resign' پر کلک کریں۔",
//   },
//   {
//     id: 39,
//     text: "میں ایپ میں اپنی دستیابی کیسے سیٹ کروں؟",
//     response:
//       "دستیابی سیٹ کرنے کے لیے 'Availability' سیکشن میں جائیں اور تاریخ یا وقت منتخب کریں۔",
//   },
//   {
//     id: 40,
//     text: "میں ایپ پر تنخواہ کیسے دیکھوں؟",
//     response:
//       "تنخواہ دیکھنے کے لیے 'Salary' سیکشن کھولیں اور اپنے شیڈول کے مطابق معلومات دیکھیں۔",
//   },
//   {
//     id: 41,
//     text: "میں ایپ میں نئی مہارتیں کیسے سیکھ سکتا ہوں؟",
//     response:
//       "نئی مہارتیں سیکھنے کے لیے 'Skills' یا 'Learning' سیکشن میں دستیاب کورسز دیکھیں۔",
//   },
//   {
//     id: 42,
//     text: "میں ایپ پر کام کے اوقات کیسے دیکھوں؟",
//     response:
//       "کام کے اوقات دیکھنے کے لیے 'Work Schedule' یا 'Shifts' سیکشن استعمال کریں۔",
//   },
//   {
//     id: 43,
//     text: "میں ایپ پر ادائیگی کے طریقے کیسے بدلوں؟",
//     response:
//       "ادائیگی کے طریقے بدلنے کے لیے 'Settings' > 'Payment Methods' میں جائیں اور نیا طریقہ منتخب کریں۔",
//   },
//   {
//     id: 44,
//     text: "میں ایپ میں ریٹنگ کیسے بڑھاؤں؟",
//     response:
//       "ریٹنگ بڑھانے کے لیے اچھا کام کریں اور کلائنٹس سے مثبت ریویوز حاصل کریں۔",
//   },
//   {
//     id: 45,
//     text: "میں ایپ پر شکایت کیسے دوں؟",
//     response: "شکایت دینے کے لیے 'Support' > 'Report Issue' استعمال کریں۔",
//   },
//   {
//     id: 46,
//     text: "میں ایپ میں کسی دوست کو کیسے مدعو کروں؟",
//     response: "دوست کو مدعو کرنے کے لیے 'Invite Friends' آپشن استعمال کریں۔",
//   },
//   {
//     id: 47,
//     text: "میں ایپ میں پرانے کام کی ریکارڈ کیسے دیکھوں؟",
//     response:
//       "پرانے کام دیکھنے کے لیے 'Work History' یا 'Jobs Completed' سیکشن کھولیں۔",
//   },
//   {
//     id: 48,
//     text: "میں ایپ میں اپ لوڈ کی گئی تصویریں کیسے دیکھوں؟",
//     response: "تصویریں دیکھنے کے لیے 'Profile' > 'Gallery' میں جائیں۔",
//   },
//   {
//     id: 49,
//     text: "میں ایپ میں ڈیجیٹل معاہدہ کیسے دیکھوں؟",
//     response:
//       "ڈیجیٹل معاہدہ دیکھنے کے لیے 'Contracts' سیکشن میں جائیں اور متعلقہ معاہدہ کھولیں۔",
//   },
//   {
//     id: 50,
//     text: "میں ایپ میں کس طرح ایمرجنسی مدد لے سکتا ہوں؟",
//     response:
//       "ایمرجنسی مدد کے لیے 'Support' > 'Emergency' استعمال کریں اور فوری رابطہ کریں۔",
//   },
//   {
//     id: 51,
//     text: "میں ایپ میں نوکری کی درخواست کب تک رکھ سکتا ہوں؟",
//     response:
//       "نوکری کی درخواست 'Jobs' میں جا کر منتخب کریں اور 'Apply' پر کلک کریں۔",
//   },
//   {
//     id: 52,
//     text: "میں ایپ میں کیسے سائن آؤٹ کروں؟",
//     response: "سائن آؤٹ کرنے کے لیے 'Settings' > 'Logout' پر کلک کریں۔",
//   },
//   {
//     id: 53,
//     text: "میں ایپ میں نوٹیفکیشن بند کیسے کروں؟",
//     response:
//       "نوٹیفکیشن بند کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور آف کریں۔",
//   },
//   {
//     id: 54,
//     text: "میں ایپ میں پروفائل فوٹو کیسے بدلوں؟",
//     response:
//       "پروفائل فوٹو بدلنے کے لیے 'Profile' > 'Edit' > 'Upload Photo' استعمال کریں۔",
//   },
//   {
//     id: 55,
//     text: "میں ایپ میں کام کی تفصیلات کیسے دیکھوں؟",
//     response:
//       "کام کی تفصیلات دیکھنے کے لیے 'Jobs' یا 'Work History' میں جائیں۔",
//   },
//   {
//     id: 56,
//     text: "میں ایپ میں دستیاب جابز کیسے فلٹر کروں؟",
//     response:
//       "جابز فلٹر کرنے کے لیے 'Jobs' میں فلٹرز استعمال کریں جیسے مقام، وقت یا تنخواہ۔",
//   },
//   {
//     id: 57,
//     text: "میں ایپ میں اپنا پروفائل کیسے ایکٹیو رکھوں؟",
//     response:
//       "پروفائل ایکٹیو رکھنے کے لیے تمام معلومات مکمل کریں اور 'Profile Active' آن کریں۔",
//   },
//   {
//     id: 58,
//     text: "میں ایپ میں کسی ٹھیکیدار کی ٹیم میں شامل کیسے ہوں؟",
//     response:
//       "ٹھیکیدار کی ٹیم میں شامل ہونے کے لیے 'Contractors' میں جائیں اور درخواست دیں۔",
//   },
//   {
//     id: 59,
//     text: "میں ایپ میں نئی جگہ پر کام کیسے تلاش کروں؟",
//     response:
//       "نئی جگہ پر کام تلاش کرنے کے لیے 'Jobs' سیکشن میں مقام منتخب کریں۔",
//   },
//   {
//     id: 60,
//     text: "میں ایپ میں تربیتی کورس کیسے دیکھوں؟",
//     response:
//       "تربیتی کورس دیکھنے کے لیے 'Learning' یا 'Skills' سیکشن استعمال کریں۔",
//   },
// ];

// const findMatchingQuestion = (text) => {
//   const lowerText = text.toLowerCase();
//   const match = questionsData.find(
//     (q) => q.text.includes(lowerText) || lowerText.includes(q.text),
//   );
//   if (match) return match;
//   const similar = questionsData.find((q) =>
//     q.text.split(" ").some((word) => lowerText.includes(word)),
//   );
//   return similar;
// };

// app.post("/api/chat", async (req, res) => {
//   try {
//     const { message } = req.body;
//     if (!message) return res.status(400).json({ error: "Message is required" });

//     // Step 1: Translate user input to Urdu
//     const translation = await openai.chat.completions.create({
//       model: "gpt-4o-mini",
//       messages: [
//         {
//           role: "system",
//           content:
//             "آپ کا کام صرف انگریزی یا کسی بھی زبان کو اردو میں ترجمہ کرنا ہے، بغیر جواب دیے۔",
//         },
//         { role: "user", content: message },
//       ],
//     });

//     const messageInUrdu = translation.choices[0].message.content.trim();

//     // Step 2: Find exact or partial match
//     const matchedQuestion = findMatchingQuestion(messageInUrdu);
//     if (matchedQuestion) {
//       return res.json({ reply: matchedQuestion.response });
//     }

//     // Step 3: Generate a context-aware answer in Urdu based on app features
//     const context = questionsData
//       .map((q) => `سوال: ${q.text} | جواب: ${q.response}`)
//       .join("\n");

//     const response = await openai.chat.completions.create({
//       model: "gpt-4o-mini",
//       messages: [
//         {
//           role: "system",
//           content: `
// آپ ایک AI اسسٹنٹ ہیں جو صرف "مزدور اور ٹھیکیدار" موبائل ایپ کے basic flow اور فیچرز کے مطابق جواب دیتا ہے۔
// - ہمیشہ جواب اردو میں دیں۔
// - ہر سوال کا جواب ایپ کے استعمال یا فیچرز کے تناظر میں دیں، جیسے لاگ ان، پروفائل، جاب پوسٹنگ، جاب اپلائی، بڈنگ، یا نوٹیفیکیشنز۔
// - اگر سوال ایپ سے براہ راست متعلق نہ ہو، تب بھی اپنی سمجھ کے مطابق سب سے قریبی جواب ایپ کے basic flow سے دیں۔
// - کبھی بھی غیر متعلقہ یا عام معلومات نہ دیں۔
// - context میں دی گئی معلومات کو جواب میں شامل کریں اگر ضروری ہو۔

// موجودہ معلومات: ${context}
//       `,
//         },
//         { role: "user", content: messageInUrdu },
//       ],
//     });

//     const reply = response.choices[0].message.content;
//     res.json({ reply });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: "سرور میں خرابی پیش آگئی" });
//   }
// });

// // Transcribe route
// app.post("/api/transcribe", upload.single("file"), async (req, res) => {
//   try {
//     if (!req.file || !req.file.path)
//       return res.status(400).json({ error: "کوئی فائل اپلوڈ نہیں ہوئی" });

//     const cloudinaryUrl = req.file.path;

//     // Download audio
//     const audioResponse = await fetch(cloudinaryUrl);
//     const audioBuffer = await audioResponse.buffer();

//     const tempInput = path.join("/tmp", `input_${Date.now()}`);
//     const tempOutput = path.join("/tmp", `output_${Date.now()}.mp3`);
//     fs.writeFileSync(tempInput, audioBuffer);

//     await new Promise((resolve, reject) => {
//       ffmpeg(tempInput)
//         .setFfmpegPath(ffmpegPath)
//         .output(tempOutput)
//         .on("end", resolve)
//         .on("error", reject)
//         .run();
//     });

//     const fileStream = fs.createReadStream(tempOutput);
//     const form = new FormData();
//     form.append("file", fileStream);
//     form.append("model", "whisper-1");

//     const whisperResponse = await fetch(
//       "https://api.openai.com/v1/audio/transcriptions",
//       {
//         method: "POST",
//         headers: {
//           Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
//           ...form.getHeaders(),
//         },
//         body: form,
//       },
//     );

//     const data = await whisperResponse.json();

//     fs.unlinkSync(tempInput);
//     fs.unlinkSync(tempOutput);

//     if (data.error) return res.status(500).json({ error: data.error.message });

//     res.json({ text: data.text || "", cloudinaryUrl });
//   } catch (err) {
//     console.error("Transcription error:", err);
//     res.status(500).json({ error: "آڈیو کو ٹیکسٹ میں تبدیل کرنے میں ناکامی" });
//   }
// });

// /* ---------- Basic middlewares ---------- */
// app.use(helmet());
// app.use(cors());
// app.use(express.json({ limit: "10kb" }));

// // small rate limiter for auth endpoints
// const authLimiter = rateLimit({
//   windowMs: 60 * 1000, // 1 minute
//   max: 10, // limit each IP to 10 requests per windowMs
//   message: { error: "Too many requests, please slow down." },
// });
// app.use("/api/", authLimiter);

// // Create HTTP server
// const server = http.createServer(app);

// // Initialize Socket.IO
// const io = new Server(server, {
//   cors: {
//     origin: "*", // Or your frontend URL
//     methods: ["GET", "POST"],
//   },
// });

// app.use("/api/chat", chatRoutes);
// notification.sendServerStartNotification().catch(console.error);

// /* ---------- Mongoose user schema ---------- */
// const userSchema = new mongoose.Schema(
//   {
//     firstName: { type: String, required: true, trim: true, maxlength: 50 },
//     lastName: { type: String, required: true, trim: true, maxlength: 50 },
//     phone: { type: String, required: true, trim: true },
//     email: {
//       type: String,
//       required: true,
//       unique: true,
//       lowercase: true,
//       trim: true,
//     },
//     passwordHash: { type: String, required: true },
//     role: { type: String, enum: ["Labour", "Contractor"], default: "Labour" },
//     image: {
//       type: String,
//       default:
//         "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762757911/Pngtree_user_profile_avatar_13369988_qdlgmg.png",
//     },
//     skills: { type: [String], default: [] },
//     expoPushToken: { type: String, default: null }, // ADD THIS LINE
//     reviews: [
//       {
//         reviewerEmail: { type: String, required: true },
//         rating: { type: Number, required: true, min: 1, max: 5 },
//         feedback: { type: String, trim: true },
//         createdAt: { type: Date, default: Date.now },
//       },
//     ],
//     createdAt: { type: Date, default: Date.now },
//   },
//   { timestamps: true },
// );

// const User = mongoose.model("User", userSchema);

// app.post(
//   "/api/update-profile-image",
//   upload.single("image"),
//   async (req, res) => {
//     const { email } = req.body;
//     if (!email) return res.status(400).json({ message: "Email is required" });
//     if (!req.file)
//       return res.status(400).json({ message: "No image uploaded" });

//     try {
//       // Save only Cloudinary URL
//       const imageUrl = req.file.path; // <-- keep this as is
//       const user = await User.findOneAndUpdate(
//         { email },
//         { image: imageUrl },
//         { new: true },
//       );

//       if (!user) return res.status(404).json({ message: "User not found" });

//       return res.status(200).json({ message: "Profile image updated", user });
//     } catch (err) {
//       console.log("Server error:", err);
//       res.status(500).json({ message: "Server error" });
//     }
//   },
// );

// app.post("/api/users/:email/review", async (req, res) => {
//   const { email } = req.params;
//   const { reviewerEmail, rating, feedback } = req.body;

//   if (!reviewerEmail || !rating) {
//     return res
//       .status(400)
//       .json({ message: "Reviewer email and rating are required" });
//   }

//   try {
//     const user = await User.findOneAndUpdate(
//       { email },
//       { $push: { reviews: { reviewerEmail, rating, feedback } } },
//       { new: true },
//     );

//     if (!user) return res.status(404).json({ message: "User not found" });

//     res.status(200).json({ message: "Review added", user });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// app.get("/api/users", async (req, res) => {
//   try {
//     const { skill, role, q } = req.query;

//     let filter = {};

//     // 🔎 Search by skill (case-insensitive)
//     if (skill) {
//       filter.skills = { $regex: skill, $options: "i" };
//     }

//     // 🔎 Filter by role
//     if (role) {
//       filter.role = role;
//     }

//     // 🔎 Search by name
//     if (q) {
//       filter.$or = [
//         { firstName: { $regex: q, $options: "i" } },
//         { lastName: { $regex: q, $options: "i" } },
//       ];
//     }

//     const users = await User.find(filter).select(
//       "firstName lastName email phone role image skills",
//     );

//     // 🏷 Add badge dynamically
//     const formattedUsers = users.map((user) => ({
//       _id: user._id,
//       name: `${user.firstName} ${user.lastName}`,
//       email: user.email,
//       phone: user.phone,
//       image: user.image,
//       skills: user.skills,
//       role: user.role,
//       badge: user.role === "Contractor" ? "🟦 Contractor" : "🟩 Labour",
//     }));

//     res.status(200).json({
//       success: true,
//       count: formattedUsers.length,
//       users: formattedUsers,
//     });
//   } catch (error) {
//     console.error("User Fetch Error:", error);
//     res.status(500).json({
//       success: false,
//       message: "Server error",
//     });
//   }
// });

// // ---------- Get Current User ----------
// app.get("/api/user/:userId", async (req, res) => {
//   try {
//     const user = await User.findById(req.params.userId);
//     if (!user) return res.status(404).json({ message: "User not found" });
//     res.json(user);
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // ---------- Get Skills by Email ----------
// app.get("/api/user/skills/:email", async (req, res) => {
//   try {
//     const email = req.params.email.toLowerCase().trim();

//     const user = await User.findOne({ email });

//     if (!user) {
//       return res
//         .status(404)
//         .json({ success: false, message: "User not found" });
//     }

//     return res.json({
//       success: true,
//       email: user.email,
//       skills: user.skills || [],
//     });
//   } catch (err) {
//     console.error("Error fetching skills:", err);
//     res.status(500).json({
//       success: false,
//       message: "Server error while fetching skills",
//     });
//   }
// });

// // ---------- Add Skill ----------
// app.post("/api/user/:email/skills", async (req, res) => {
//   try {
//     const email = req.params.email.toLowerCase().trim();
//     const { skill } = req.body;

//     if (!skill || !skill.trim()) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Skill is required" });
//     }

//     const user = await User.findOne({ email });

//     if (!user) {
//       return res
//         .status(404)
//         .json({ success: false, message: "User not found" });
//     }

//     // Prevent duplicates
//     if (user.skills.includes(skill.trim())) {
//       return res.json({ success: true, message: "Skill already exists" });
//     }

//     user.skills.push(skill.trim());
//     await user.save();

//     return res.json({
//       success: true,
//       message: "Skill added successfully",
//       skills: user.skills,
//     });
//   } catch (err) {
//     console.error("Error adding skill:", err);
//     res
//       .status(500)
//       .json({ success: false, message: "Server error while adding skill" });
//   }
// });

// // ---------- Delete Skill ----------
// app.delete("/api/user/:email/skills/:index", async (req, res) => {
//   try {
//     const email = req.params.email.toLowerCase().trim();
//     const index = parseInt(req.params.index);

//     const user = await User.findOne({ email });

//     if (!user) {
//       return res
//         .status(404)
//         .json({ success: false, message: "User not found" });
//     }

//     if (index < 0 || index >= user.skills.length) {
//       return res
//         .status(400)
//         .json({ success: false, message: "Invalid skill index" });
//     }

//     // Remove the skill by index
//     user.skills.splice(index, 1);
//     await user.save();

//     return res.json({
//       success: true,
//       message: "Skill deleted successfully",
//       skills: user.skills,
//     });
//   } catch (err) {
//     console.error("Error deleting skill:", err);
//     res
//       .status(500)
//       .json({ success: false, message: "Server error while deleting skill" });
//   }
// });

// // Get user by email
// app.get("/api/user-by-email/:email", async (req, res) => {
//   try {
//     const { email } = req.params;
//     const user = await User.findOne({ email }).select(
//       "firstName lastName email image role",
//     );
//     if (!user) return res.status(404).json({ message: "User not found" });
//     res.json(user);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// /* ---------- Helpers ---------- */

// function validateSignupPayload(payload) {
//   const errors = [];

//   if (!payload.firstName || String(payload.firstName).trim().length < 2) {
//     errors.push("First name is required (min 2 characters).");
//   }
//   if (!payload.lastName || String(payload.lastName).trim().length < 1) {
//     errors.push("Last name is required.");
//   }
//   if (
//     !payload.phone ||
//     !/^\+?[0-9]{7,15}$/.test(String(payload.phone).trim())
//   ) {
//     errors.push(
//       "Phone is required (digits only, 7-15 chars, optional leading +).",
//     );
//   }
//   if (!payload.email || !validator.isEmail(String(payload.email))) {
//     errors.push("A valid email is required.");
//   }
//   if (!payload.password || String(payload.password).length < 6) {
//     errors.push("Password is required (min 6 characters).");
//   }
//   if (!payload.role || !["Labour", "Contractor"].includes(payload.role)) {
//     errors.push("Role must be either 'Labour' or 'Contractor'.");
//   }

//   return errors;
// }

// function signJwt(user) {
//   const secret = process.env.JWT_SECRET;
//   const expiresIn = process.env.JWT_EXPIRES_IN || "7d";
//   return jwt.sign(
//     { sub: user._id.toString(), email: user.email, role: user.role },
//     secret,
//     { expiresIn },
//   );
// }

// /* ---------- API routes ---------- */

// /**
//  * POST /api/signup
//  * body: { firstName, lastName, phone, email, password, role }
//  */
// app.post("/api/signup", async (req, res) => {
//   try {
//     const { firstName, lastName, phone, email, password, role, expoPushToken } =
//       req.body || {};
//     // validate input
//     const validationErrors = validateSignupPayload({
//       firstName,
//       lastName,
//       phone,
//       email,
//       password,
//       role,
//       expoPushToken: expoPushToken || null, // Add this
//     });
//     if (validationErrors.length) {
//       return res.status(400).json({ errors: validationErrors });
//     }

//     // normalize email/phone
//     const normalizedEmail = String(email).trim().toLowerCase();
//     const normalizedPhone = String(phone).trim();

//     // check duplicate email
//     const existing = await User.findOne({ email: normalizedEmail }).lean();
//     if (existing) {
//       return res.status(409).json({ error: "Email already in use." });
//     }

//     // hash password
//     const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || "10", 10);
//     const passwordHash = await bcrypt.hash(password, saltRounds);

//     // create user
//     const user = new User({
//       firstName: String(firstName).trim(),
//       lastName: String(lastName).trim(),
//       phone: normalizedPhone,
//       email: normalizedEmail,
//       passwordHash,
//       role,
//     });

//     await user.save();

//     // sign token
//     const token = signJwt(user);

//     // return user data (excluding passwordHash)
//     const userResponse = {
//       id: user._id,
//       firstName: user.firstName,
//       lastName: user.lastName,
//       phone: user.phone,
//       email: user.email,
//       role: user.role,
//       createdAt: user.createdAt,
//     };

//     return res.status(201).json({ user: userResponse, token });
//   } catch (err) {
//     console.error("Signup error:", err);
//     return res.status(500).json({ error: "Internal server error." });
//   }
// });

// // Update the login route to store push token
// app.post("/api/login", async (req, res) => {
//   try {
//     const { email, password, expoPushToken } = req.body || {};

//     if (!email || !password)
//       return res.status(400).json({ error: "Email and password required." });

//     const user = await User.findOne({
//       email: String(email).trim().toLowerCase(),
//     });

//     if (!user) return res.status(401).json({ error: "Invalid credentials." });

//     const ok = await bcrypt.compare(password, user.passwordHash);
//     if (!ok) return res.status(401).json({ error: "Invalid credentials." });

//     // Store the push token if provided
//     if (expoPushToken) {
//       user.expoPushToken = expoPushToken;
//       await user.save();
//       console.log(
//         `✅ Saved push token for ${email}: ${expoPushToken.substring(0, 30)}...`,
//       );
//     }

//     const token = signJwt(user);
//     return res.json({
//       user: {
//         id: user._id,
//         firstName: user.firstName,
//         lastName: user.lastName,
//         email: user.email,
//         phone: user.phone,
//         role: user.role,
//       },
//       token,
//     });
//   } catch (err) {
//     console.error("Login error:", err);
//     return res.status(500).json({ error: "Internal server error." });
//   }
// });
// /* Protected test endpoint example */
// app.get("/api/me", async (req, res) => {
//   try {
//     const auth = req.headers.authorization;
//     if (!auth || !auth.startsWith("Bearer "))
//       return res.status(401).json({ error: "Missing token." });
//     const token = auth.slice(7);
//     const secret = process.env.JWT_SECRET;
//     const decoded = jwt.verify(token, secret);
//     const userId = decoded.sub;
//     const user = await User.findById(userId).lean();
//     if (!user) return res.status(404).json({ error: "User not found." });

//     return res.json({
//       user: {
//         id: user._id,
//         email: user.email,
//         firstName: user.firstName,
//         role: user.role,
//       },
//     });
//   } catch (err) {
//     console.error("Auth error:", err);
//     return res.status(401).json({ error: "Invalid or expired token." });
//   }
// });

// // ===================== FORGOT PASSWORD =====================
// // Check if user exists by email
// app.post("/api/forgot-password", async (req, res) => {
//   try {
//     const { email } = req.body;
//     if (!email) return res.status(400).json({ error: "Email is required." });

//     const user = await User.findOne({
//       email: String(email).trim().toLowerCase(),
//     });
//     if (!user)
//       return res
//         .status(404)
//         .json({ error: "No account found with this email." });

//     // You can send a reset email here if you want.
//     return res
//       .status(200)
//       .json({ message: "User found. Proceed to reset password." });
//   } catch (err) {
//     console.error("Forgot Password error:", err);
//     return res.status(500).json({ error: "Internal server error." });
//   }
// });

// const client = twilio(
//   process.env.TWILIO_ACCOUNT_SID,
//   process.env.TWILIO_AUTH_TOKEN,
// );

// // ---------------- SendGrid Setup ----------------
// sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// app.post("/api/reset-password", async (req, res) => {
//   try {
//     const { email, newPassword } = req.body;
//     if (!email || !newPassword)
//       return res
//         .status(400)
//         .json({ error: "Email and new password are required." });

//     const user = await User.findOne({
//       email: String(email).trim().toLowerCase(),
//     });
//     if (!user) return res.status(404).json({ error: "User not found." });

//     const isSame = await bcrypt.compare(newPassword, user.passwordHash);
//     if (isSame)
//       return res.status(400).json({
//         error: "New password must be different from your old password.",
//       });

//     const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || "10", 10);
//     const passwordHash = await bcrypt.hash(newPassword, saltRounds);
//     user.passwordHash = passwordHash;
//     await user.save();

//     // ---------------- Read and Encode Logo ----------------
//     const logoUrl =
//       "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762834364/logo_je7mnb.png";

//     // ---------------- Send Email ----------------
//     try {
//       const msg = {
//         to: user.email,
//         from: process.env.SENDGRID_VERIFIED_SENDER,
//         subject: "Labour Hub - Password Changed Successfully",
//         html: `
//     <div style="font-family: 'Segoe UI', sans-serif; background-color: #f5f7fa; padding: 40px 0;">
//       <div style="max-width: 600px; background-color: #ffffff; margin: 0 auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">

//         <div style="background-color: #0a66c2; padding: 25px 20px; text-align: center;">
//           <img src="${logoUrl}" alt="Labour Hub Logo" width="70" height="70" style="border-radius: 50%; border: 2px solid #ffffff; margin-bottom: 10px;">
//           <h1 style="color: #ffffff; font-size: 24px; margin: 0;">Labour Hub</h1>
//         </div>

//         <div style="padding: 30px 25px; color: #333333;">
//           <h2 style="color: #0a66c2; font-size: 20px;">Password Changed Successfully</h2>
//           <p style="font-size: 16px; line-height: 1.6;">
//             Dear <strong>${user.email}</strong>,<br><br>
//             Your <strong>Labour Hub</strong> account password has been changed successfully.
//           </p>
//           <p>If this wasn't you, please contact our support team immediately.</p>
//           <div style="text-align: center; margin-top: 30px;">
//             <a href="https://labourhub.pk/login" style="background-color: #0a66c2; color: white; text-decoration: none; padding: 12px 25px; border-radius: 8px; font-weight: bold;">
//               Go to Login
//             </a>
//           </div>
//         </div>

//         <div style="background-color: #f0f2f5; text-align: center; padding: 20px; border-top: 1px solid #e1e4e8;">
//           <p style="color: #777777; font-size: 13px; margin: 0;">
//             &copy; ${new Date().getFullYear()} Labour Hub. All rights reserved.<br>
//             Karachi, Pakistan
//           </p>
//         </div>
//       </div>
//     </div>
//   `,
//       };
//       await sgMail.send(msg);

//       await sgMail.send(msg);
//       console.log(`✅ Email sent successfully to ${user.email}`);
//     } catch (err) {
//       console.error(
//         "Email send failed:",
//         err.response ? err.response.body : err,
//       );
//     }

//     return res.status(200).json({ message: "Password reset successfully!" });
//   } catch (err) {
//     console.error("Reset Password error:", err);
//     return res.status(500).json({ error: "Internal server error." });
//   }
// });

// const DEFAULT_IMAGE =
//   "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png";

// // API to get user by ID
// app.get("/api/user/:id", async (req, res) => {
//   try {
//     const user = await User.findById(req.params.id).select(
//       "firstName lastName role email image",
//     );
//     if (!user) return res.status(404).json({ message: "User not found" });

//     res.json({
//       firstName: user.firstName || "",
//       lastName: user.lastName || "",
//       role: user.role || "",
//       email: user.email || "",
//       image:
//         user.image && user.image.trim() !== "" ? user.image : DEFAULT_IMAGE,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // ==================== SCHEMA ====================
// const jobSchema = new mongoose.Schema(
//   {
//     title: String,
//     description: String,
//     location: String,
//     workersRequired: Number,
//     skill: String,
//     budget: Number,
//     contact: String,
//     startDate: Date,
//     endDate: Date,
//     shift: { type: String, default: "Shift A" },
//     jobTime: { type: Date, default: Date.now },

//     createdBy: {
//       userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//       firstName: String,
//       lastName: String,
//       role: String,
//       email: String,
//     },
//     applicants: [
//       {
//         laborId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
//         appliedAt: { type: Date, default: Date.now },
//         status: {
//           type: String,
//           enum: ["pending", "accepted", "rejected"],
//           default: "pending",
//         },
//         chatId: { type: mongoose.Schema.Types.ObjectId, ref: "Chat" },
//       },
//     ],
//     noOfWorkersApplied: { type: Number, default: 0 }, // NEW
//   },
//   { timestamps: true },
// );

// const Job = mongoose.model("Job", jobSchema);

// const jobApplicationSchema = new mongoose.Schema({
//   jobId: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
//   contractorEmail: { type: String, required: true },
//   labourEmail: { type: String, required: true },
//   appliedAt: { type: Date, default: Date.now },
// });

// const JobApplication = mongoose.model("JobApplication", jobApplicationSchema);
// module.exports = JobApplication;

// app.post("/api/jobs/apply/:jobId", async (req, res) => {
//   const { jobId } = req.params;
//   const { labourId, labourEmail } = req.body;

//   try {
//     const job = await Job.findById(jobId);
//     if (!job) return res.status(404).json({ message: "Job not found" });

//     // Check if labour already applied
//     const alreadyApplied = job.applicants.some(
//       (app) => app.laborId && app.laborId.toString() === labourId,
//     );

//     if (alreadyApplied)
//       return res.status(400).json({ message: "Already applied" });

//     // Add labour to job
//     job.applicants.push({
//       laborId: labourId,
//       appliedAt: new Date(),
//       status: "pending",
//     });
//     job.noOfWorkersApplied = job.applicants.length;
//     await job.save();

//     // Save in JobApplications collection
//     await JobApplication.create({
//       jobId: job._id,
//       contractorEmail: job.createdBy.email,
//       labourEmail,
//     });

//     res.status(200).json({ message: "Applied successfully", job });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server Error" });
//   }
// });

// // ==================== ROUTE ====================
// // Create a new job
// app.post("/api/jobs", async (req, res) => {
//   try {
//     const {
//       title,
//       description,
//       location,
//       workersRequired,
//       skill,
//       budget,
//       contact,
//       startDate,
//       endDate,
//       createdBy,
//       shift,
//       jobTime,
//     } = req.body;

//     if (
//       !title ||
//       !description ||
//       !location ||
//       !workersRequired ||
//       !skill ||
//       !budget ||
//       !contact ||
//       !startDate ||
//       !endDate
//     ) {
//       return res.status(400).json({ message: "All fields are required." });
//     }

//     const job = new Job({
//       title,
//       description,
//       location,
//       workersRequired,
//       skill,
//       budget,
//       contact,
//       startDate,
//       endDate,
//       shift: shift || "Shift A",
//       jobTime: jobTime || new Date(),
//       createdBy: {
//         userId: createdBy.userId,
//         firstName: createdBy.firstName,
//         lastName: createdBy.lastName,
//         role: createdBy.role,
//         email: createdBy.email,
//       },
//     });

//     await job.save();

//     // ============================================
//     // SEND PUSH NOTIFICATIONS TO ALL LABOUR USERS
//     // ============================================
//     let notificationResult = { successCount: 0, failCount: 0 };

//     try {
//       // Get all Labour users who have push tokens
//       const labourUsers = await User.find({
//         role: "Labour",
//         expoPushToken: { $exists: true, $ne: null, $ne: "" },
//       }).select("expoPushToken firstName lastName email");

//       console.log(
//         `📱 Found ${labourUsers.length} labour users with push tokens`,
//       );

//       if (labourUsers.length > 0) {
//         notificationResult = await notification.notifyLabourUsersAboutNewJob(
//           labourUsers,
//           job,
//         );
//         console.log(
//           `📊 Notification Summary: ${notificationResult.successCount} sent, ${notificationResult.failCount} failed`,
//         );
//       } else {
//         console.log("⚠️ No labour users with push tokens found.");
//       }
//     } catch (notifError) {
//       console.error("❌ Notification error:", notifError);
//       // Don't fail the job creation if notification fails
//     }

//     return res.status(201).json({
//       message: "Job created successfully",
//       job,
//       notificationsSent: notificationResult.successCount,
//     });
//   } catch (err) {
//     console.error("Error creating job:", err);
//     return res.status(500).json({ message: "Server error" });
//   }
// });
// // Add this route after your other routes (around line 700)
// app.post("/api/update-push-token", async (req, res) => {
//   try {
//     const { email, expoPushToken } = req.body;

//     if (!email || !expoPushToken) {
//       return res.status(400).json({ error: "Email and token required" });
//     }

//     const user = await User.findOneAndUpdate(
//       { email: email.toLowerCase().trim() },
//       { expoPushToken: expoPushToken },
//       { new: true },
//     );

//     if (!user) {
//       return res.status(404).json({ error: "User not found" });
//     }

//     console.log(
//       `✅ Updated push token for ${email}: ${expoPushToken.substring(0, 30)}...`,
//     );
//     res.json({ success: true, message: "Token updated" });
//   } catch (err) {
//     console.error("Token update error:", err);
//     res.status(500).json({ error: "Server error" });
//   }
// });

// // ==================== 1. Get all jobs ====================
// app.get("/api/alljobs", async (req, res) => {
//   try {
//     const jobs = await Job.find().sort({ createdAt: -1 }); // latest jobs first
//     res.status(200).json(jobs);
//   } catch (err) {
//     console.error("Error fetching jobs:", err);
//     res.status(500).json({ message: "Server Error" });
//   }
// });
// // Add this temporary endpoint to manually add a token
// app.post("/api/manual-add-token", async (req, res) => {
//   try {
//     const { email, expoPushToken } = req.body;

//     if (!email || !expoPushToken) {
//       return res.status(400).json({ error: "Email and token required" });
//     }

//     const user = await User.findOneAndUpdate(
//       { email: email.toLowerCase().trim(), role: "Labour" },
//       { expoPushToken: expoPushToken },
//       { new: true },
//     );

//     if (!user) {
//       return res
//         .status(404)
//         .json({ error: "Labour user not found with this email" });
//     }

//     console.log(`✅ Manually added token for Labour user: ${email}`);
//     res.json({
//       success: true,
//       message: `Token added for ${email}`,
//       user: { email: user.email, role: user.role, hasToken: true },
//     });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });
// // Add this temporary debug route after your other routes
// app.get("/api/debug-users", async (req, res) => {
//   try {
//     const allUsers = await User.find({}).select(
//       "email role expoPushToken createdAt",
//     );

//     const usersWithTokens = allUsers.filter(
//       (u) => u.expoPushToken && u.expoPushToken !== null,
//     );
//     const labourUsers = allUsers.filter((u) => u.role === "Labour");
//     const labourWithTokens = labourUsers.filter(
//       (u) => u.expoPushToken && u.expoPushToken !== null,
//     );

//     res.json({
//       totalUsers: allUsers.length,
//       usersWithTokens: usersWithTokens.length,
//       labourUsers: labourUsers.length,
//       labourWithTokens: labourWithTokens.length,
//       details: allUsers.map((u) => ({
//         email: u.email,
//         role: u.role,
//         hasToken: !!u.expoPushToken,
//         tokenPreview: u.expoPushToken
//           ? u.expoPushToken.substring(0, 30) + "..."
//           : null,
//         createdAt: u.createdAt,
//       })),
//     });
//   } catch (err) {
//     res.status(500).json({ error: err.message });
//   }
// });

// // ==================== 2. Get jobs created by a specific contractor by email ====================
// app.get("/api/my-jobs-email/:email", async (req, res) => {
//   const { email } = req.params;
//   try {
//     const jobs = await Job.find({ "createdBy.email": email }).sort({
//       createdAt: -1,
//     });
//     res.status(200).json(jobs);
//   } catch (err) {
//     console.error(`Error fetching jobs for ${email}:`, err);
//     res.status(500).json({ message: "Server Error" });
//   }
// });

// app.get("/api/filter", async (req, res) => {
//   try {
//     const {
//       userEmail, // current logged-in user to exclude their jobs
//       location,
//       skill,
//       startDate,
//       endDate,
//       minBudget,
//       maxBudget,
//     } = req.query;

//     // Build dynamic query
//     const query = {};

//     // Exclude current user's jobs
//     if (userEmail) {
//       query["createdBy.email"] = { $ne: userEmail };
//     }

//     if (location) query.location = location;
//     if (skill) query.skill = skill;

//     if (startDate && endDate) {
//       query.startDate = { $gte: new Date(startDate) };
//       query.endDate = { $lte: new Date(endDate) };
//     } else if (startDate) {
//       query.startDate = { $gte: new Date(startDate) };
//     } else if (endDate) {
//       query.endDate = { $lte: new Date(endDate) };
//     }

//     if (minBudget || maxBudget) {
//       query.budget = {};
//       if (minBudget) query.budget.$gte = Number(minBudget);
//       if (maxBudget) query.budget.$lte = Number(maxBudget);
//     }

//     // Fetch filtered jobs
//     const jobs = await Job.find(query).sort({ createdAt: -1 });

//     // Fetch dropdown options dynamically
//     const cities = await Job.distinct("location");
//     const skillsList = await Job.distinct("skill");

//     res.status(200).json({
//       filters: { cities, skills: skillsList },
//       jobs,
//     });
//   } catch (err) {
//     console.error("Filter Jobs Error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // ==================== PROFILE API ====================
// app.get("/api/profile/:email", async (req, res) => {
//   try {
//     const { email } = req.params;

//     const user = await User.findOne({ email: email.trim().toLowerCase() })
//       .select("firstName lastName role email image createdAt reviews")
//       .lean();

//     if (!user) return res.status(404).json({ message: "User not found" });

//     const DEFAULT_IMAGE =
//       "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png";
//     user.image = user.image?.trim() || DEFAULT_IMAGE;

//     // ⭐ Reviews logic
//     const reviews = user.reviews || [];
//     const totalReviews = reviews.length;
//     const averageRating =
//       totalReviews > 0
//         ? (
//             reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
//           ).toFixed(1)
//         : 0;

//     let jobsCreated = [];
//     let jobsApplied = [];
//     let totalApplicantsOnJobs = 0;

//     if (user.role === "Contractor") {
//       jobsCreated = await Job.find({ "createdBy.email": email }).lean();
//       totalApplicantsOnJobs = jobsCreated.reduce(
//         (acc, job) => acc + (job.applicants?.length || 0),
//         0,
//       );
//     } else {
//       const applications = await Job.find({
//         "applicants.laborId": user._id,
//       }).lean();
//       jobsApplied = applications.map((job) => {
//         const applicant = job.applicants.find(
//           (a) => a.laborId.toString() === user._id.toString(),
//         );
//         return {
//           jobId: job._id,
//           title: job.title,
//           status: applicant?.status || "pending",
//           appliedAt: applicant?.appliedAt || null,
//           contractor: job.createdBy,
//         };
//       });
//     }

//     res.json({
//       user: {
//         ...user,
//         averageRating,
//         totalReviews,
//       },
//       reviews, // ⭐ FULL REVIEWS ARRAY
//       stats: {
//         totalJobsPosted: jobsCreated.length,
//         totalJobsApplied: jobsApplied.length,
//         totalApplicantsOnJobs,
//       },
//       jobsCreated,
//       jobsApplied,
//     });
//   } catch (err) {
//     console.error("Profile API error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // ==================== Get jobs a user applied to ====================
// app.get("/api/jobs/user/:email", async (req, res) => {
//   try {
//     const { email } = req.params;

//     // Find user
//     const user = await User.findOne({
//       email: email.trim().toLowerCase(),
//     }).lean();
//     if (!user) return res.status(404).json({ message: "User not found" });

//     // Jobs the user created (if Contractor)
//     const jobsCreated = await Job.find({ "createdBy.email": email })
//       .sort({ createdAt: -1 })
//       .lean();

//     // Jobs the user applied to (from JobApplication collection)
//     const jobApplications = await JobApplication.find({
//       labourEmail: email,
//     }).lean();

//     const jobsApplied = [];
//     for (const app of jobApplications) {
//       const job = await Job.findById(app.jobId).lean();
//       if (!job) continue;

//       jobsApplied.push({
//         jobId: job._id,
//         title: job.title,
//         status: "pending", // default or you can extend to fetch from Job.applicants
//         appliedAt: app.appliedAt,
//         contractor: {
//           firstName: job.createdBy.firstName,
//           lastName: job.createdBy.lastName,
//           email: job.createdBy.email,
//           role: job.createdBy.role,
//           image:
//             job.createdBy.image ||
//             "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png",
//         },
//       });
//     }

//     res.status(200).json({
//       user: {
//         firstName: user.firstName,
//         lastName: user.lastName,
//         email: user.email,
//         role: user.role,
//         image:
//           user.image ||
//           "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png",
//       },
//       stats: {
//         totalJobsPosted: jobsCreated.length,
//         totalJobsApplied: jobsApplied.length,
//       },
//       jobsCreated,
//       jobsApplied,
//     });
//   } catch (err) {
//     console.error("Error fetching user jobs:", err);
//     res.status(500).json({ message: "Server Error" });
//   }
// });

// // ==================== Get all responses for jobs posted by a contractor ====================
// app.get("/api/responses-by-contractor/:email", async (req, res) => {
//   try {
//     const { email } = req.params;

//     // Step 1: Find all job applications for this contractor
//     const applications = await JobApplication.find({
//       contractorEmail: email,
//     }).lean();
//     if (!applications || applications.length === 0) {
//       return res
//         .status(404)
//         .json({ message: "No responses found for this contractor" });
//     }

//     // Step 2: For each application, fetch job info and labour info
//     const results = [];
//     for (const app of applications) {
//       const job = await Job.findById(app.jobId).lean();
//       if (!job) continue;

//       const labour = await User.findOne({ email: app.labourEmail }).lean();

//       results.push({
//         applicationId: app._id,
//         jobId: job._id,
//         jobTitle: job.title,
//         jobDescription: job.description,
//         location: job.location,
//         workersRequired: job.workersRequired,
//         appliedAt: app.appliedAt,
//         labour: {
//           labourId: labour?._id || null,
//           firstName: labour?.firstName || "Unknown",
//           lastName: labour?.lastName || "Unknown",
//           email: labour?.email || app.labourEmail,
//           role: labour?.role || "Labour",
//           image:
//             labour?.image ||
//             "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png",
//         },
//       });
//     }

//     res.status(200).json({
//       contractorEmail: email,
//       totalResponses: results.length,
//       responses: results,
//     });
//   } catch (err) {
//     console.error("Error fetching contractor responses:", err);
//     res.status(500).json({ message: "Server Error" });
//   }
// });

// // ==================== SEARCH JOBS (by skill + name) ====================
// app.get("/api/search-jobs", async (req, res) => {
//   try {
//     const { skill, name } = req.query;

//     // Build query object dynamically
//     const query = {};

//     if (skill && skill.trim() !== "") {
//       query.skill = { $regex: new RegExp(skill, "i") }; // case-insensitive match
//     }

//     if (name && name.trim() !== "") {
//       query.title = { $regex: new RegExp(name, "i") };
//     }

//     const jobs = await Job.find(query).sort({ createdAt: -1 });

//     return res.json({
//       success: true,
//       count: jobs.length,
//       jobs,
//     });
//   } catch (err) {
//     console.error("Search Jobs Error:", err);
//     res.status(500).json({
//       success: false,
//       message: "Server error while searching jobs",
//     });
//   }
// });

// app.post("/api/apply/:jobId", async (req, res) => {
//   try {
//     const { jobId } = req.params;
//     const { labourEmail } = req.body; // get email from frontend

//     if (!labourEmail) {
//       return res.status(400).json({ message: "Labour email is required" });
//     }

//     // Fetch job
//     const job = await Job.findById(jobId);
//     if (!job) return res.status(404).json({ message: "Job not found" });

//     // Check if already applied
//     const exists = await JobApplication.findOne({ jobId, labourEmail });
//     if (exists) return res.status(400).json({ message: "Already applied" });

//     const application = new JobApplication({
//       jobId,
//       contractorEmail: job.createdBy.email,
//       labourEmail,
//     });

//     await application.save();

//     // Update job's applicant count
//     job.noOfWorkersApplied = (job.noOfWorkersApplied || 0) + 1;
//     await job.save();

//     res.status(200).json({ success: true, application });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // // ------------------- Chat Schema -------------------
// // const chatSchema = new mongoose.Schema(
// //   {
// //     participants: [{ type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }],
// //     messages: [
// //       {
// //         sender: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
// //         text: { type: String, required: true },
// //         timestamp: { type: Date, default: Date.now },
// //       },
// //     ],
// //   },
// //   { timestamps: true }
// // );

// // const Chat = mongoose.model("Chat", chatSchema);

// // // ------------------- API -------------------
// // // Get chat history between two users
// // app.get("/api/chats/:user1/:user2", async (req, res) => {
// //   try {
// //     // Use `new` keyword for ObjectId
// //     const user1 = new mongoose.Types.ObjectId(req.params.user1);
// //     const user2 = new mongoose.Types.ObjectId(req.params.user2);

// //     let chat = await Chat.findOne({ participants: { $all: [user1, user2] } })
// //       .populate("messages.sender", "firstName lastName email image")
// //       .lean();

// //     if (!chat) chat = { messages: [] };

// //     const messagesWithSenderInfo = chat.messages.map((msg) => ({
// //       ...msg,
// //       senderInfo: msg.sender,
// //     }));

// //     res.json({ messages: messagesWithSenderInfo });
// //   } catch (err) {
// //     console.error("Fetch chat error:", err);
// //     res.status(500).json({ message: "Server error" });
// //   }
// // });

// // // ------------------- Socket.IO -------------------
// // io.on("connection", (socket) => {
// //   console.log("New socket connected:", socket.id);

// //   // Join room
// //   socket.on("join", (userId) => {
// //     socket.join(userId);
// //     console.log(`User ${userId} joined room`);
// //   });

// //   // Send message
// //   socket.on("sendMessage", async ({ senderId, receiverId, text }) => {
// //     try {
// //       if (!senderId || !receiverId || !text.trim()) return;

// //       const senderObjId = mongoose.Types.ObjectId(senderId);
// //       const receiverObjId = mongoose.Types.ObjectId(receiverId);

// //       let chat = await Chat.findOne({
// //         participants: { $all: [senderObjId, receiverObjId] },
// //       });

// //       if (!chat) chat = new Chat({ participants: [senderObjId, receiverObjId], messages: [] });

// //       chat.messages.push({ sender: senderObjId, text });
// //       await chat.save();

// //       const populatedChat = await Chat.findById(chat._id).populate(
// //         "messages.sender",
// //         "firstName lastName email image"
// //       );

// //       const lastMessage = populatedChat.messages[populatedChat.messages.length - 1].toObject();

// //       const messageToSend = { ...lastMessage, senderInfo: lastMessage.sender };

// //       // Emit to both users
// //       io.to(senderId).emit("receiveMessage", messageToSend);
// //       io.to(receiverId).emit("receiveMessage", messageToSend);

// //       console.log("Message saved and sent:", messageToSend);
// //     } catch (err) {
// //       console.error("Send message error:", err);
// //     }
// //   });
// // });

// // Get user by email
// app.get("/api/get-user-by-email/:email", async (req, res) => {
//   try {
//     const user = await User.findOne({ email: req.params.email }).lean();
//     if (!user) return res.status(404).json({ message: "User not found" });
//     res.json({ id: user._id });
//   } catch (err) {
//     console.error("Fetch user error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // ================= Check Application Status (Using Logged-in User) =================
// app.get("/api/check-application/:jobId", async (req, res) => {
//   try {
//     const { jobId } = req.params;
//     const userEmail = req.query.email?.trim().toLowerCase();

//     if (!userEmail) {
//       return res.status(400).json({ message: "Email is required for testing" });
//     }

//     const application = await JobApplication.findOne({
//       jobId,
//       labourEmail: userEmail,
//     });

//     res.json({
//       applied: !!application,
//       message: application ? "User already applied" : "User has not applied",
//     });
//   } catch (err) {
//     console.error("Error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // Industry Mongoose Schema
// const industrySchema = new mongoose.Schema(
//   {
//     industry: { type: String, required: true },
//     owner: { type: String, required: true },
//     email: { type: String, required: true, unique: true },
//     phone: { type: String, required: true },
//     address: { type: String, required: true },
//     textileType: { type: String, required: true },
//     password: { type: String, required: true }, // hashed

//     // ✅ NEW FIELD
//     active: { type: Boolean, default: false },
//   },
//   { timestamps: true },
// );

// const Industry = mongoose.model("Industry", industrySchema);

// // Create Industry API
// app.post("/api/industries", async (req, res) => {
//   try {
//     const { industry, owner, email, phone, address, textileType, password } =
//       req.body;

//     // Validate required fields
//     if (
//       !industry ||
//       !owner ||
//       !email ||
//       !phone ||
//       !address ||
//       !textileType ||
//       !password
//     ) {
//       return res.status(400).json({ message: "All fields are required" });
//     }

//     if (!validator.isEmail(email)) {
//       return res.status(400).json({ message: "Invalid email format" });
//     }

//     if (password.length < 8) {
//       return res
//         .status(400)
//         .json({ message: "Password must be at least 8 characters" });
//     }

//     // Check if email already exists
//     const existing = await Industry.findOne({ email });
//     if (existing)
//       return res.status(400).json({ message: "Email already registered" });

//     // Hash password
//     const hashedPassword = await bcrypt.hash(password, 10);

//     // Save to DB (active will default to false)
//     const newIndustry = await Industry.create({
//       industry,
//       owner,
//       email,
//       phone,
//       address,
//       textileType,
//       password: hashedPassword,
//     });

//     res.status(201).json({
//       message: "Industry registered successfully",
//       industry: newIndustry,
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // Get all active industries except current logged-in one
// app.get("/api/industries/all", async (req, res) => {
//   try {
//     const { email, search } = req.query;

//     let query = {
//       active: true,
//       email: { $ne: email }, // exclude logged-in industry
//     };

//     if (search) {
//       query.industry = { $regex: search, $options: "i" };
//     }

//     const industries = await Industry.find(query).select(
//       "industry email address textileType",
//     );

//     res.status(200).json(industries);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// const borrowSchema = new mongoose.Schema(
//   {
//     fromIndustryEmail: { type: String, required: true },
//     toIndustryEmail: { type: String, required: true },

//     labourRequired: Number,
//     skills: String,
//     description: String,
//     date: String,
//     time: String,
//     location: String,

//     status: { type: String, default: "Pending" },
//   },
//   { timestamps: true },
// );

// const Borrow = mongoose.model("Borrow", borrowSchema);

// app.post("/api/borrow", async (req, res) => {
//   try {
//     // 1️⃣ Save borrow request
//     const borrow = await Borrow.create(req.body);

//     res.status(201).json({
//       message: "Borrow request sent",
//       borrow,
//     });

//     // 2️⃣ EMAIL LOGIC (AFTER RESPONSE)
//     const {
//       toIndustryEmail,
//       fromIndustryEmail,
//       labourRequired,
//       skills,
//       description,
//       fromDate,
//       toDate,
//       shift,
//       shiftTime,
//       location,
//     } = req.body;

//     if (!toIndustryEmail) {
//       console.error("❌ toIndustryEmail missing");
//       return;
//     }

//     const msg = {
//       to: toIndustryEmail, // ✅ FIXED
//       from: process.env.SENDGRID_VERIFIED_SENDER,
//       subject: "Labour Hub - New Labour Borrow Request",
//       html: `
//       <div style="font-family: 'Segoe UI', sans-serif; background:#f5f7fa; padding:40px 0;">
//         <div style="max-width:620px; margin:auto; background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 10px 25px rgba(0,0,0,.12)">

//           <!-- HEADER -->
//           <div style="background:linear-gradient(135deg,#0a66c2,#004182); padding:26px; text-align:center;">
//             <h1 style="color:#fff; margin:0;">Labour Hub</h1>
//             <p style="color:#dbeafe; margin-top:6px;">New Borrow Request</p>
//           </div>

//           <!-- BODY -->
//           <div style="padding:30px; color:#1f2937;">
//             <p>
//               You have received a <strong>new labour borrow request</strong>
//               from <strong>${fromIndustryEmail}</strong>.
//             </p>

//             <div style="margin-top:20px; background:#f9fafb; padding:20px; border-radius:12px; border:1px solid #e5e7eb;">
//               <table width="100%" style="font-size:14px;">
//                 <tr><td>Labour Required</td><td><strong>${labourRequired}</strong></td></tr>
//                 <tr><td>Skills</td><td><strong>${skills}</strong></td></tr>
//                 <tr><td>Duration</td><td>${fromDate} → ${toDate}</td></tr>
//                 <tr><td>Shift</td><td>${shift} (${shiftTime})</td></tr>
//                 <tr><td>Location</td><td>${location}</td></tr>
//                 <tr><td>Description</td><td>${description}</td></tr>
//               </table>
//             </div>

//             <div style="text-align:center; margin-top:30px;">
//               <a href="https://labourhub.pk/dashboard"
//                  style="background:#0a66c2; color:#fff; padding:12px 28px;
//                  border-radius:10px; text-decoration:none; font-weight:600;">
//                 View Request
//               </a>
//             </div>
//           </div>

//           <!-- FOOTER -->
//           <div style="background:#f3f4f6; padding:18px; text-align:center; font-size:13px; color:#6b7280;">
//             © ${new Date().getFullYear()} Labour Hub · Karachi, Pakistan
//           </div>
//         </div>
//       </div>
//       `,
//     };

//     await sgMail.send(msg);
//     console.log("✅ Borrow request email sent to", toIndustryEmail);
//   } catch (err) {
//     console.error("❌ Borrow API error:", err);
//   }
// });

// // ==================== API to Get Borrow Records for Logged-in User ====================
// app.get("/api/my-borrows/:email", async (req, res) => {
//   try {
//     const userEmail = req.params.email; // Logged-in user's email

//     // Find all borrows where this user applied (as fromIndustryEmail)
//     const myBorrows = await Borrow.find({ fromIndustryEmail: userEmail });

//     if (!myBorrows.length) {
//       return res.status(404).json({ message: "No borrow records found." });
//     }

//     res.status(200).json(myBorrows);
//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // Get borrow requests sent TO the logged-in user
// app.get("/api/incoming-borrows/:email", async (req, res) => {
//   try {
//     const userEmail = req.params.email;

//     const incomingBorrows = await Borrow.find({ toIndustryEmail: userEmail });

//     if (!incomingBorrows.length) {
//       return res.status(404).json({ message: "No incoming requests." });
//     }

//     res.status(200).json(incomingBorrows);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // ==================== Approve Borrow API ====================
// app.post("/api/approve-borrow/:id", async (req, res) => {
//   try {
//     const borrowId = req.params.id;

//     // Find the borrow request
//     const borrow = await Borrow.findById(borrowId);
//     if (!borrow) {
//       return res.status(404).json({ message: "Borrow request not found." });
//     }

//     // Update status to Approved
//     borrow.status = "Approved";
//     await borrow.save();

//     // ✅ Attempt to send email, but don't crash if it fails
//     if (borrow.fromIndustryEmail && process.env.SENDGRID_VERIFIED_SENDER) {
//       const msg = {
//         to: borrow.fromIndustryEmail,
//         from: process.env.SENDGRID_VERIFIED_SENDER,
//         subject: "Labour Hub - Borrow Request Approved",
//         html: `
//         <div style="font-family: 'Segoe UI', sans-serif; background:#f5f7fa; padding:40px 0;">
//           <div style="max-width:620px; margin:auto; background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 10px 25px rgba(0,0,0,.12)">
//             <div style="background:linear-gradient(135deg,#0a66c2,#004182); padding:26px; text-align:center;">
//               <h1 style="color:#fff; margin:0;">Labour Hub</h1>
//               <p style="color:#dbeafe; margin-top:6px;">Borrow Request Approved</p>
//             </div>
//             <div style="padding:30px; color:#1f2937;">
//               <p>Your borrow request to <strong>${borrow.toIndustryEmail}</strong> has been <strong>approved</strong>.</p>
//               <div style="margin-top:20px; background:#f9fafb; padding:20px; border-radius:12px; border:1px solid #e5e7eb;">
//                 <table width="100%" style="font-size:14px;">
//                   <tr><td>Labour Required</td><td><strong>${borrow.labourRequired}</strong></td></tr>
//                   <tr><td>Skills</td><td><strong>${borrow.skills}</strong></td></tr>
//                   <tr><td>Date</td><td>${borrow.date}</td></tr>
//                   <tr><td>Time</td><td>${borrow.time}</td></tr>
//                   <tr><td>Location</td><td>${borrow.location}</td></tr>
//                   <tr><td>Description</td><td>${borrow.description}</td></tr>
//                 </table>
//               </div>
//             </div>
//             <div style="background:#f3f4f6; padding:18px; text-align:center; font-size:13px; color:#6b7280;">
//               © ${new Date().getFullYear()} Labour Hub · Karachi, Pakistan
//             </div>
//           </div>
//         </div>
//         `,
//       };

//       try {
//         await sgMail.send(msg);
//         console.log("✅ Approval email sent to", borrow.fromIndustryEmail);
//       } catch (emailErr) {
//         console.error("⚠️ Email failed to send:", emailErr.message);
//       }
//     } else {
//       console.log("⚠️ No email configured or sender missing. Skipping email.");
//     }

//     res.status(200).json({ message: "Borrow request approved", borrow });
//   } catch (err) {
//     console.error("❌ Approve borrow error:", err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // app.post("/api/borrow", async (req, res) => {
// //   try {
// //     const borrow = await Borrow.create(req.body);

// //     const {
// //       toIndustryEmail,
// //       fromIndustryEmail,
// //       labourRequired,
// //       skills,
// //       description,
// //       fromDate,
// //       toDate,
// //       shift,
// //       shiftTime,
// //       location,
// //     } = req.body;

// //     if (!toIndustryEmail) {
// //       return res.status(400).json({ error: "toIndustryEmail missing" });
// //     }

// //     const msg = {
// //       to: toIndustryEmail,
// //       from: process.env.SENDGRID_VERIFIED_SENDER, // MUST be verified
// //       subject: "Labour Hub - New Labour Borrow Request",
// //       html: `...your same html...`,
// //     };

// //     await sgMail.send(msg);

// //     console.log("✅ Borrow email sent to", toIndustryEmail);

// //     return res.status(201).json({
// //       message: "Borrow request sent successfully",
// //       borrow,
// //     });

// //   } catch (err) {
// //     console.error("❌ Borrow API error:", err.response?.body || err);
// //     return res.status(500).json({ error: "Borrow request failed" });
// //   }
// // });

// app.post("/api/industries/login", async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password) {
//       return res
//         .status(400)
//         .json({ message: "Email and password are required" });
//     }

//     if (!validator.isEmail(email)) {
//       return res.status(400).json({ message: "Invalid email format" });
//     }

//     const industry = await Industry.findOne({ email });
//     if (!industry)
//       return res.status(400).json({ message: "Invalid credentials" });

//     const isMatch = await bcrypt.compare(password, industry.password);
//     if (!isMatch)
//       return res.status(400).json({ message: "Invalid credentials" });

//     // ✅ Send active status
//     const token = jwt.sign(
//       { id: industry._id, email: industry.email },
//       "YOUR_SECRET_KEY",
//       { expiresIn: "7d" },
//     );

//     res.status(200).json({
//       message: "Login successful",
//       email: industry.email,
//       token,
//       active: industry.active, // 🔥 IMPORTANT
//     });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// // API to get industry profile by email
// app.get("/api/industries/profile", async (req, res) => {
//   try {
//     const { email } = req.query;

//     if (!email || typeof email !== "string") {
//       return res.status(400).json({ message: "Email is required" });
//     }

//     const industry = await Industry.findOne({ email }).select("-password"); // exclude password
//     if (!industry) {
//       return res.status(404).json({ message: "Industry not found" });
//     }

//     res.status(200).json(industry);
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// app.post("/api/admin/industry-toggle/:id", async (req, res) => {
//   try {
//     const industry = await Industry.findById(req.params.id);
//     if (!industry) return res.status(404).json({ error: "Industry not found" });

//     industry.active = !industry.active;
//     await industry.save();

//     // redirect back to admin panel
//     res.redirect("/api/admin");
//   } catch (err) {
//     console.error(err);
//     res.status(500).send("Server error");
//   }
// });

// app.get("/api/admin", async (req, res) => {
//   try {
//     const users = await User.find().lean();
//     const jobs = await Job.find().lean();
//     const applications = await JobApplication.find().lean();
//     const industries = await Industry.find().lean();
//     const borrows = await Borrow.find().lean();

//     const html = `
// <!DOCTYPE html>
// <html>
// <head>
//   <title>Labour Hub | Admin Panel</title>
//   <meta charset="UTF-8" />
//   <style>
//     body {
//       font-family: "Segoe UI", sans-serif;
//       background: #f4f6f9;
//       padding: 20px;
//     }
//     h1 {
//       color: #0a66c2;
//       margin-bottom: 10px;
//     }
//     h2 {
//       margin-top: 40px;
//       color: #111827;
//       border-left: 6px solid #0a66c2;
//       padding-left: 10px;
//     }
//     table {
//       width: 100%;
//       border-collapse: collapse;
//       margin-top: 15px;
//       background: #ffffff;
//       box-shadow: 0 6px 18px rgba(0,0,0,.06);
//       border-radius: 10px;
//       overflow: hidden;
//     }
//     th, td {
//       padding: 10px;
//       border-bottom: 1px solid #e5e7eb;
//       font-size: 14px;
//       text-align: left;
//     }
//     th {
//       background: #0a66c2;
//       color: #ffffff;
//       font-weight: 600;
//     }
//     tr:nth-child(even) {
//       background: #f9fafb;
//     }
//     tr:hover {
//       background: #eef2ff;
//     }
//       .toggle-btn {
//   border: none;
//   padding: 6px 14px;
//   border-radius: 6px;
//   font-size: 12px;
//   font-weight: 600;
//   cursor: pointer;
//   color: #fff;
// }

// .toggle-btn.green { background: #16a34a; }
// .toggle-btn.red { background: #dc2626; }

// .toggle-btn:hover {
//   opacity: 0.9;
// }

//     .badge {
//       padding: 4px 8px;
//       border-radius: 6px;
//       font-size: 12px;
//       color: white;
//     }
//     .green { background: #16a34a; }
//     .red { background: #dc2626; }
//     .blue { background: #2563eb; }
//     .gray { background: #6b7280; }
//     footer {
//       margin-top: 40px;
//       text-align: center;
//       color: #6b7280;
//       font-size: 13px;
//     }
//   </style>
// </head>

// <body>

// <h1>📊 Labour Hub – Admin Panel</h1>

// <!-- USERS -->
// <h2>👤 Users</h2>
// <table>
// <tr>
//   <th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Skills</th><th>Created</th>
// </tr>
// ${users
//   .map(
//     (u) => `
// <tr>
//   <td>${u.firstName} ${u.lastName}</td>
//   <td>${u.email}</td>
//   <td>${u.phone}</td>
//   <td><span class="badge blue">${u.role}</span></td>
//   <td>${u.skills?.join(", ") || "-"}</td>
//   <td>${new Date(u.createdAt).toLocaleString()}</td>
// </tr>`,
//   )
//   .join("")}
// </table>

// <!-- JOBS -->
// <h2>🛠 Jobs</h2>
// <table>
// <tr>
//   <th>Title</th><th>Location</th><th>Skill</th><th>Budget</th>
//   <th>Workers</th><th>Applicants</th><th>Posted By</th>
// </tr>
// ${jobs
//   .map(
//     (j) => `
// <tr>
//   <td>${j.title}</td>
//   <td>${j.location}</td>
//   <td>${j.skill}</td>
//   <td>${j.budget}</td>
//   <td>${j.workersRequired}</td>
//   <td>${j.noOfWorkersApplied || 0}</td>
//   <td>${j.createdBy?.email || "-"}</td>
// </tr>`,
//   )
//   .join("")}
// </table>

// <!-- JOB APPLICATIONS -->
// <h2>📄 Job Applications</h2>
// <table>
// <tr>
//   <th>Job ID</th><th>Contractor</th><th>Labour</th><th>Date</th>
// </tr>
// ${applications
//   .map(
//     (a) => `
// <tr>
//   <td>${a.jobId}</td>
//   <td>${a.contractorEmail}</td>
//   <td>${a.labourEmail}</td>
//   <td>${new Date(a.appliedAt).toLocaleString()}</td>
// </tr>`,
//   )
//   .join("")}
// </table>
// <!-- INDUSTRIES -->
// <h2>🏭 Industries</h2>
// <table>
// <tr>
//   <th>Industry</th>
//   <th>Owner</th>
//   <th>Email</th>
//   <th>Phone</th>
//   <th>Textile</th>
//   <th>Status (Click)</th>
// </tr>

// ${industries
//   .map(
//     (i) => `
// <tr>
//   <td>${i.industry}</td>
//   <td>${i.owner}</td>
//   <td>${i.email}</td>
//   <td>${i.phone}</td>
//   <td>${i.textileType}</td>
//   <td>
// <td>
//   <form
//     method="POST"
//     action="/api/admin/industry-toggle/${i._id}"
//     onsubmit="return confirm('${
//       i.active
//         ? "Are you sure you want to DEACTIVATE this industry?"
//         : "Are you sure you want to ACTIVATE this industry?"
//     }'
//     );"
//   >
//     <button
//       type="submit"
//       class="toggle-btn ${i.active ? "green" : "red"}"
//     >
//       ${i.active ? "Active" : "Inactive"}
//     </button>
//   </form>
// </td>

// </tr>
// `,
//   )
//   .join("")}

// </table>

// <!-- BORROW REQUESTS -->
// <h2>🔄 Borrow Requests</h2>
// <table>
// <tr>
//   <th>From</th><th>To</th><th>Labour</th><th>Skills</th>
//   <th>Location</th><th>Status</th>
// </tr>
// ${borrows
//   .map(
//     (b) => `
// <tr>
//   <td>${b.fromIndustryEmail}</td>
//   <td>${b.toIndustryEmail}</td>
//   <td>${b.labourRequired}</td>
//   <td>${b.skills}</td>
//   <td>${b.location}</td>
//   <td>
//     <span class="badge ${
//       b.status === "Approved"
//         ? "green"
//         : b.status === "Rejected"
//           ? "red"
//           : "gray"
//     }">${b.status}</span>
//   </td>
// </tr>`,
//   )
//   .join("")}
// </table>

// <footer>
//   © ${new Date().getFullYear()} Labour Hub · Admin Panel
// </footer>
// <script>
//   function toggleIndustry(id, currentStatus) {
//     const action = currentStatus ? "deactivate" : "activate";

//     if (!confirm("Are you sure you want to " + action + " this industry?")) {
//       return;
//     }

//     fetch(window.location.origin + "/api/admin/industry-toggle/" + id, {
//       method: "POST"
//     })
//     .then(res => {
//       if (!res.ok) throw new Error("Request failed");
//       return res.json();
//     })
//     .then(data => {
//       alert("Industry is now " + (data.active ? "Active" : "Inactive"));
//       location.reload();
//     })
//     .catch(err => {
//       console.error(err);
//       alert("Failed to update industry status");
//     });
//   }
// </script>

// </body>
// </html>
// `;

//     res.send(html);
//   } catch (err) {
//     console.error(err);
//     res.status(500).send("Server Error");
//   }
// });

// /* ---------- DB connect & server start ---------- */
// async function start() {
//   if (!process.env.MONGO_URI) {
//     console.error("MONGO_URI missing in .env");
//     process.exit(1);
//   }
//   if (!process.env.JWT_SECRET) {
//     console.error("JWT_SECRET missing in .env");
//     process.exit(1);
//   }

//   try {
//     await mongoose.connect(process.env.MONGO_URI, {
//       useNewUrlParser: true,
//       useUnifiedTopology: true,
//     });
//     console.log("Connected to MongoDB");
//   } catch (err) {
//     console.error("Failed to connect to MongoDB:", err);
//     process.exit(1);
//   }
// }

// start();

// // Root endpoint
// app.get("/", (req, res) => res.send("🚀 Labour Hub APIs areS running!"));

// const port = process.env.PORT || 3000;
// app.listen(port, () =>
//   console.log(`✅ Server running at http://localhost:${port}`),
// );

/////////////////////////////////////////////////// LATEST ONE ///////////////////////////////////////
const express = require("express");
const multer = require("multer");
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const fs = require("fs");
const http = require("http");
const path = require("path");
const ffmpeg = require("fluent-ffmpeg");
const ffmpegPath = require("ffmpeg-static");
const FormData = require("form-data");
const fetch = require("node-fetch"); // npm install node-fetch@2
const OpenAI = require("openai");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const validator = require("validator");
const twilio = require("twilio");
const sgMail = require("@sendgrid/mail");
const chatRoutes = require("./chat");
const { Server } = require("socket.io");
require("dotenv").config();
const notification = require("./notification");

const app = express();
app.use(express.json());

// ─── Cloudinary config ───────────────────────────────────────────────────────
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const storage = new CloudinaryStorage({
  cloudinary,
  params: { folder: "audio_uploads", resource_type: "auto" },
});
const upload = multer({ storage });

// ─── OpenAI ──────────────────────────────────────────────────────────────────
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// ─── Predefined Q&A ──────────────────────────────────────────────────────────
const questionsData = [
  {
    id: 1,
    text: "میری پروفائل کیسے بناؤں؟",
    response:
      "پروفائل بنانے کے لیے 'پروفائل' سیکشن میں جائیں، تمام معلومات بھریں اور 'سیو' پر کلک کریں۔",
  },
  {
    id: 2,
    text: "میں ملازمت کے لیے کیسے درخواست دوں؟",
    response:
      "ملازمت کے لیے درخواست دینے کے لیے 'Jobs' میں جائیں، مطلوبہ نوکری منتخب کریں اور 'Apply' پر کلک کریں۔",
  },
  {
    id: 3,
    text: "میرے قریب کون سے ملز میں کام ہے؟",
    response:
      "قریبی ملز دیکھنے کے لیے 'Nearby Jobs' سیکشن کھولیں اور دستیاب مواقع دیکھیں۔",
  },
  {
    id: 4,
    text: "میں اپنی مہارتیں کیسے اپ ڈیٹ کروں؟",
    response:
      "مہارتیں اپ ڈیٹ کرنے کے لیے 'Skills' سیکشن میں جائیں، نئی مہارتیں شامل کریں اور 'Save' کریں۔",
  },
  {
    id: 5,
    text: "کیا میں کسی ٹھیکیدار کی ٹیم میں شامل ہو سکتا ہوں؟",
    response:
      "جی ہاں، 'Contractors' میں جائیں اور ٹیم میں شامل ہونے کے لیے درخواست دیں۔",
  },
  {
    id: 6,
    text: "نئی نوکریوں کے بارے میں اطلاع کیسے ملے گی؟",
    response:
      "نئی نوکریوں کی اطلاع کے لیے 'Notifications' آن کریں یا ایپ کی اپ ڈیٹس دیکھیں۔",
  },
  {
    id: 7,
    text: "میں اپنی موجودگی کب تک ظاہر کروں؟",
    response:
      "موجودگی ظاہر کرنے کے لیے 'Attendance' سیکشن میں جائیں اور اپنی موجودگی اپ ڈیٹ کریں۔",
  },
  {
    id: 8,
    text: "میرے کام کی تنخواہ کب ملے گی؟",
    response:
      "تنخواہ کی تاریخ 'Salary' سیکشن میں دیکھیں یا اپنے کمپنی کے شیڈول کے مطابق۔",
  },
  {
    id: 9,
    text: "میں کس طرح ڈیجیٹل معاہدہ دیکھ سکتا ہوں؟",
    response:
      "ڈیجیٹل معاہدہ دیکھنے کے لیے 'Contracts' سیکشن میں جائیں اور متعلقہ معاہدہ کھولیں۔",
  },
  {
    id: 10,
    text: "میں اپنی ریٹنگ کیسے دیکھ سکتا ہوں؟",
    response: "اپنی ریٹنگ دیکھنے کے لیے 'Profile' یا 'Ratings' سیکشن کھولیں۔",
  },
  {
    id: 11,
    text: "کیا میں نوکری چھوڑنا چاہوں تو کیسے کروں؟",
    response:
      "نوکری چھوڑنے کے لیے 'Jobs' سیکشن میں جائیں اور 'Resign' آپشن استعمال کریں۔",
  },
  {
    id: 12,
    text: "میں کس طرح اپنی جگہ کا پتہ درست کر سکتا ہوں؟",
    response:
      "اپنی جگہ درست کرنے کے لیے 'Settings' > 'Location' میں جائیں اور درست پتہ درج کریں۔",
  },
  {
    id: 13,
    text: "میں کس طرح زیادہ قریبی ملازمت تلاش کر سکتا ہوں؟",
    response:
      "قریبی ملازمتیں تلاش کرنے کے لیے 'Nearby Jobs' سیکشن میں فلٹرز استعمال کریں۔",
  },
  {
    id: 14,
    text: "میں اپنی پروفائل میں تصویریں کیسے ڈالوں؟",
    response:
      "پروفائل میں تصاویر شامل کرنے کے لیے 'Profile' > 'Edit' > 'Upload Photo' پر جائیں۔",
  },
  {
    id: 15,
    text: "کیا میں کسی دوسرے مل میں بھی کام کر سکتا ہوں؟",
    response:
      "جی ہاں، 'Jobs' سیکشن میں مختلف ملز کے مواقع دیکھیں اور درخواست دیں۔",
  },
  {
    id: 16,
    text: "میں اپنی دستیابی کب تبدیل کر سکتا ہوں؟",
    response:
      "اپنی دستیابی تبدیل کرنے کے لیے 'Availability' سیکشن میں جائیں اور نئی تاریخ یا وقت سیٹ کریں۔",
  },
  {
    id: 17,
    text: "نوکری کے بارے میں نوٹیفکیشن کیسے آن کریں؟",
    response:
      "نوٹیفکیشن آن کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور متعلقہ آپشن آن کریں۔",
  },
  {
    id: 18,
    text: "میں ٹھیکیدار کے ساتھ کیسے رابطہ کروں؟",
    response:
      "ٹھیکیدار سے رابطہ کرنے کے لیے 'Contractors' میں جائیں اور 'Contact' آپشن استعمال کریں۔",
  },
  {
    id: 19,
    text: "میری کام کی ریکارڈ کیسے دیکھیں؟",
    response:
      "کام کی ریکارڈ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن کھولیں۔",
  },
  {
    id: 20,
    text: "کیا میں اپنی تنخواہ کا حساب خود دیکھ سکتا ہوں؟",
    response:
      "جی ہاں، 'Salary' سیکشن میں جائیں اور 'Salary Calculator' استعمال کریں۔",
  },
  {
    id: 21,
    text: "میں نئی مہارتیں کیسے سیکھ سکتا ہوں؟",
    response:
      "نئی مہارتیں سیکھنے کے لیے 'Learning' یا 'Skills' سیکشن میں دستیاب کورسز دیکھیں۔",
  },
  {
    id: 22,
    text: "میں کسی شکایت یا مسئلے کی اطلاع کیسے دوں؟",
    response:
      "شکایت یا مسئلے کی اطلاع دینے کے لیے 'Support' > 'Report Issue' استعمال کریں۔",
  },
  {
    id: 23,
    text: "میں کون سے ملز کے ساتھ کام کر چکا ہوں دیکھ سکتا ہوں؟",
    response:
      "اپنے کام کیے گئے ملز دیکھنے کے لیے 'Work History' یا 'Jobs Completed' سیکشن کھولیں۔",
  },
  {
    id: 24,
    text: "کیا میں کسی دوست کو بھی ایپ پر لاؤ سکتا ہوں؟",
    response:
      "جی ہاں، 'Invite Friends' آپشن استعمال کریں اور دوست کو ایپ پر مدعو کریں۔",
  },
  {
    id: 25,
    text: "میں اپنے کام کی تاریخ کیسے دیکھوں؟",
    response:
      "اپنے کام کی تاریخ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن استعمال کریں۔",
  },
  {
    id: 26,
    text: "کیا میں ادائیگی کے طریقے بدل سکتا ہوں؟",
    response:
      "ادائیگی کے طریقے بدلنے کے لیے 'Settings' > 'Payment Methods' میں جائیں اور نیا طریقہ منتخب کریں۔",
  },
  {
    id: 27,
    text: "میں اپنی پروفائل بند کیسے کروں؟",
    response:
      "پروفائل بند کرنے کے لیے 'Profile' > 'Settings' > 'Deactivate Account' استعمال کریں۔",
  },
  {
    id: 28,
    text: "میں نئی جگہ پر کیسے کام تلاش کروں؟",
    response:
      "نئی جگہ پر کام تلاش کرنے کے لیے 'Jobs' سیکشن میں فلٹرز کے ذریعے مقام منتخب کریں۔",
  },
  {
    id: 29,
    text: "میں کام کے اوقات کیسے دیکھ سکتا ہوں؟",
    response:
      "کام کے اوقات دیکھنے کے لیے 'Work Schedule' یا 'Shifts' سیکشن کھولیں۔",
  },
  {
    id: 30,
    text: "میں کس طرح اپنے کام کی درجہ بندی بڑھا سکتا ہوں؟",
    response:
      "کام کی درجہ بندی بڑھانے کے لیے اچھا کام کریں، ریویوز حاصل کریں اور 'Ratings' اپ ڈیٹ کریں۔",
  },
  {
    id: 31,
    text: "ایپ کو کیسے چلائیں؟",
    response:
      "ایپ کو چلانے کے لیے اسے انسٹال کریں، لاگ ان کریں اور مین مینو سے اپنے فیچرز استعمال کریں۔",
  },
  {
    id: 32,
    text: "میں اپنا پاسورڈ کیسے بدل سکتا ہوں؟",
    response: "پاسورڈ بدلنے کے لیے 'Settings' > 'Change Password' میں جائیں۔",
  },
  {
    id: 33,
    text: "میں ایپ میں نوٹیفکیشن کیسے آن کروں؟",
    response:
      "نوٹیفکیشن آن کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور مطلوبہ آپشن آن کریں۔",
  },
  {
    id: 34,
    text: "میں ایپ میں نئی نوکری کیسے دیکھوں؟",
    response:
      "نئی نوکری دیکھنے کے لیے 'Jobs' سیکشن کھولیں اور فلٹرز استعمال کریں۔",
  },
  {
    id: 35,
    text: "میں ایپ میں اپنی پروفائل اپ ڈیٹ کیسے کروں؟",
    response:
      "پروفائل اپ ڈیٹ کرنے کے لیے 'Profile' > 'Edit' میں جائیں اور معلومات بدلیں۔",
  },
  {
    id: 36,
    text: "میں ایپ پر اپنے کام کی رپورٹ کیسے دیکھوں؟",
    response:
      "کام کی رپورٹ دیکھنے کے لیے 'Work History' یا 'Attendance' سیکشن استعمال کریں۔",
  },
  {
    id: 37,
    text: "میں ایپ میں کسی ٹھیکیدار سے کیسے رابطہ کروں؟",
    response:
      "ٹھیکیدار سے رابطہ کرنے کے لیے 'Contractors' > 'Contact' استعمال کریں۔",
  },
  {
    id: 38,
    text: "میں ایپ پر نوکری چھوڑنے کا طریقہ کیا ہے؟",
    response: "نوکری چھوڑنے کے لیے 'Jobs' میں جائیں اور 'Resign' پر کلک کریں۔",
  },
  {
    id: 39,
    text: "میں ایپ میں اپنی دستیابی کیسے سیٹ کروں؟",
    response:
      "دستیابی سیٹ کرنے کے لیے 'Availability' سیکشن میں جائیں اور تاریخ یا وقت منتخب کریں۔",
  },
  {
    id: 40,
    text: "میں ایپ پر تنخواہ کیسے دیکھوں؟",
    response:
      "تنخواہ دیکھنے کے لیے 'Salary' سیکشن کھولیں اور اپنے شیڈول کے مطابق معلومات دیکھیں۔",
  },
  {
    id: 41,
    text: "میں ایپ میں نئی مہارتیں کیسے سیکھ سکتا ہوں؟",
    response:
      "نئی مہارتیں سیکھنے کے لیے 'Skills' یا 'Learning' سیکشن میں دستیاب کورسز دیکھیں۔",
  },
  {
    id: 42,
    text: "میں ایپ پر کام کے اوقات کیسے دیکھوں؟",
    response:
      "کام کے اوقات دیکھنے کے لیے 'Work Schedule' یا 'Shifts' سیکشن استعمال کریں۔",
  },
  {
    id: 43,
    text: "میں ایپ پر ادائیگی کے طریقے کیسے بدلوں؟",
    response:
      "ادائیگی کے طریقے بدلنے کے لیے 'Settings' > 'Payment Methods' میں جائیں اور نیا طریقہ منتخب کریں۔",
  },
  {
    id: 44,
    text: "میں ایپ میں ریٹنگ کیسے بڑھاؤں؟",
    response:
      "ریٹنگ بڑھانے کے لیے اچھا کام کریں اور کلائنٹس سے مثبت ریویوز حاصل کریں۔",
  },
  {
    id: 45,
    text: "میں ایپ پر شکایت کیسے دوں؟",
    response: "شکایت دینے کے لیے 'Support' > 'Report Issue' استعمال کریں۔",
  },
  {
    id: 46,
    text: "میں ایپ میں کسی دوست کو کیسے مدعو کروں؟",
    response: "دوست کو مدعو کرنے کے لیے 'Invite Friends' آپشن استعمال کریں۔",
  },
  {
    id: 47,
    text: "میں ایپ میں پرانے کام کی ریکارڈ کیسے دیکھوں؟",
    response:
      "پرانے کام دیکھنے کے لیے 'Work History' یا 'Jobs Completed' سیکشن کھولیں۔",
  },
  {
    id: 48,
    text: "میں ایپ میں اپ لوڈ کی گئی تصویریں کیسے دیکھوں؟",
    response: "تصویریں دیکھنے کے لیے 'Profile' > 'Gallery' میں جائیں۔",
  },
  {
    id: 49,
    text: "میں ایپ میں ڈیجیٹل معاہدہ کیسے دیکھوں؟",
    response:
      "ڈیجیٹل معاہدہ دیکھنے کے لیے 'Contracts' سیکشن میں جائیں اور متعلقہ معاہدہ کھولیں۔",
  },
  {
    id: 50,
    text: "میں ایپ میں کس طرح ایمرجنسی مدد لے سکتا ہوں؟",
    response:
      "ایمرجنسی مدد کے لیے 'Support' > 'Emergency' استعمال کریں اور فوری رابطہ کریں۔",
  },
  {
    id: 51,
    text: "میں ایپ میں نوکری کی درخواست کب تک رکھ سکتا ہوں؟",
    response:
      "نوکری کی درخواست 'Jobs' میں جا کر منتخب کریں اور 'Apply' پر کلک کریں۔",
  },
  {
    id: 52,
    text: "میں ایپ میں کیسے سائن آؤٹ کروں؟",
    response: "سائن آؤٹ کرنے کے لیے 'Settings' > 'Logout' پر کلک کریں۔",
  },
  {
    id: 53,
    text: "میں ایپ میں نوٹیفکیشن بند کیسے کروں؟",
    response:
      "نوٹیفکیشن بند کرنے کے لیے 'Settings' > 'Notifications' میں جائیں اور آف کریں۔",
  },
  {
    id: 54,
    text: "میں ایپ میں پروفائل فوٹو کیسے بدلوں؟",
    response:
      "پروفائل فوٹو بدلنے کے لیے 'Profile' > 'Edit' > 'Upload Photo' استعمال کریں۔",
  },
  {
    id: 55,
    text: "میں ایپ میں کام کی تفصیلات کیسے دیکھوں؟",
    response:
      "کام کی تفصیلات دیکھنے کے لیے 'Jobs' یا 'Work History' میں جائیں۔",
  },
  {
    id: 56,
    text: "میں ایپ میں دستیاب جابز کیسے فلٹر کروں؟",
    response:
      "جابز فلٹر کرنے کے لیے 'Jobs' میں فلٹرز استعمال کریں جیسے مقام، وقت یا تنخواہ۔",
  },
  {
    id: 57,
    text: "میں ایپ میں اپنا پروفائل کیسے ایکٹیو رکھوں؟",
    response:
      "پروفائل ایکٹیو رکھنے کے لیے تمام معلومات مکمل کریں اور 'Profile Active' آن کریں۔",
  },
  {
    id: 58,
    text: "میں ایپ میں کسی ٹھیکیدار کی ٹیم میں شامل کیسے ہوں؟",
    response:
      "ٹھیکیدار کی ٹیم میں شامل ہونے کے لیے 'Contractors' میں جائیں اور درخواست دیں۔",
  },
  {
    id: 59,
    text: "میں ایپ میں نئی جگہ پر کام کیسے تلاش کروں؟",
    response:
      "نئی جگہ پر کام تلاش کرنے کے لیے 'Jobs' سیکشن میں مقام منتخب کریں۔",
  },
  {
    id: 60,
    text: "میں ایپ میں تربیتی کورس کیسے دیکھوں؟",
    response:
      "تربیتی کورس دیکھنے کے لیے 'Learning' یا 'Skills' سیکشن استعمال کریں۔",
  },
];

const findMatchingQuestion = (text) => {
  const lowerText = text.toLowerCase();
  const match = questionsData.find(
    (q) => q.text.includes(lowerText) || lowerText.includes(q.text),
  );
  if (match) return match;
  return questionsData.find((q) =>
    q.text.split(" ").some((word) => lowerText.includes(word)),
  );
};

// ─── AI Chat ─────────────────────────────────────────────────────────────────
app.post("/api/chatbot", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required" });

    const translation = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "آپ کا کام صرف انگریزی یا کسی بھی زبان کو اردو میں ترجمہ کرنا ہے، بغیر جواب دیے۔",
        },
        { role: "user", content: message },
      ],
    });
    const messageInUrdu = translation.choices[0].message.content.trim();

    const matchedQuestion = findMatchingQuestion(messageInUrdu);
    if (matchedQuestion) return res.json({ reply: matchedQuestion.response });

    const context = questionsData
      .map((q) => `سوال: ${q.text} | جواب: ${q.response}`)
      .join("\n");
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `آپ ایک AI اسسٹنٹ ہیں جو صرف "مزدور اور ٹھیکیدار" موبائل ایپ کے basic flow اور فیچرز کے مطابق جواب دیتا ہے۔\nہمیشہ جواب اردو میں دیں۔\ncontext: ${context}`,
        },
        { role: "user", content: messageInUrdu },
      ],
    });

    res.json({ reply: response.choices[0].message.content });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "سرور میں خرابی پیش آگئی" });
  }
});

// ─── Transcribe ──────────────────────────────────────────────────────────────
app.post("/api/transcribe", upload.single("file"), async (req, res) => {
  try {
    if (!req.file || !req.file.path)
      return res.status(400).json({ error: "کوئی فائل اپلوڈ نہیں ہوئی" });

    const cloudinaryUrl = req.file.path;
    const audioResponse = await fetch(cloudinaryUrl);
    const audioBuffer = await audioResponse.buffer();

    const tempInput = path.join("/tmp", `input_${Date.now()}`);
    const tempOutput = path.join("/tmp", `output_${Date.now()}.mp3`);
    fs.writeFileSync(tempInput, audioBuffer);

    await new Promise((resolve, reject) => {
      ffmpeg(tempInput)
        .setFfmpegPath(ffmpegPath)
        .output(tempOutput)
        .on("end", resolve)
        .on("error", reject)
        .run();
    });

    const fileStream = fs.createReadStream(tempOutput);
    const form = new FormData();
    form.append("file", fileStream);
    form.append("model", "whisper-1");

    const whisperResponse = await fetch(
      "https://api.openai.com/v1/audio/transcriptions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
          ...form.getHeaders(),
        },
        body: form,
      },
    );

    const data = await whisperResponse.json();
    fs.unlinkSync(tempInput);
    fs.unlinkSync(tempOutput);

    if (data.error) return res.status(500).json({ error: data.error.message });
    res.json({ text: data.text || "", cloudinaryUrl });
  } catch (err) {
    console.error("Transcription error:", err);
    res.status(500).json({ error: "آڈیو کو ٹیکسٹ میں تبدیل کرنے میں ناکامی" });
  }
});

// ─── Basic middleware ─────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "10kb" }));

const authLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: "Too many requests, please slow down." },
});
app.use("/api/", authLimiter);

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] },
});

// Replace SendGrid with Nodemailer
const nodemailer = require("nodemailer");

// Configure SMTP transporter
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASS,
  },
});

// Verify SMTP connection
transporter.verify((error, success) => {
  if (error) {
    console.error("❌ SMTP Connection Error:", error);
  } else {
    console.log("✅ SMTP Server is ready to send emails");
  }
});

// ==================== EMAIL HELPER FUNCTIONS (UPDATED for SMTP) ====================

/**
 * Send email to a single user using SMTP
 */
async function sendSingleEmail(toEmail, subject, htmlContent) {
  try {
    const mailOptions = {
      from: `"Labour Hub" <${process.env.SMTP_EMAIL}>`,
      to: toEmail,
      subject: subject,
      html: htmlContent,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(
      `✅ Email sent successfully to ${toEmail} - Message ID: ${info.messageId}`,
    );
    return true;
  } catch (err) {
    console.error(`❌ Error sending email to ${toEmail}:`, err.message);
    return false;
  }
}

/**
 * Send bulk emails to multiple users
 */
async function sendBulkEmails(users, subject, getHtmlContent) {
  let successCount = 0;
  let failCount = 0;

  for (const user of users) {
    try {
      const htmlContent = getHtmlContent(user);
      await sendSingleEmail(user.email, subject, htmlContent);
      successCount++;
      // Add small delay to avoid rate limiting (Gmail allows ~100 emails/day)
      await new Promise((resolve) => setTimeout(resolve, 500));
    } catch (err) {
      failCount++;
      console.error(`Failed to send email to ${user.email}:`, err.message);
    }
  }

  return { successCount, failCount };
}

/**
 * Generate email HTML for new job post
 */
function getNewJobEmailHTML(job, jobPosterName) {
  const logoUrl =
    "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762834364/logo_je7mnb.png";
  const applyUrl = `https://labourhub.pk/job-details/${job._id}`;

  return `
    <div style="font-family: 'Segoe UI', sans-serif; background-color: #f5f7fa; padding: 40px 0;">
      <div style="max-width: 600px; background-color: #ffffff; margin: 0 auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        
        <div style="background-color: #0a66c2; padding: 25px 20px; text-align: center;">
          <img src="${logoUrl}" alt="Labour Hub Logo" width="70" height="70" style="border-radius: 50%; border: 2px solid #ffffff; margin-bottom: 10px;">
          <h1 style="color: #ffffff; font-size: 24px; margin: 0;">Labour Hub</h1>
          <p style="color: #ffffff; margin: 5px 0 0;">New Job Opportunity!</p>
        </div>

        <div style="padding: 30px 25px; color: #333333;">
          <h2 style="color: #0a66c2; font-size: 20px; margin-top: 0;">🆕 New Job Posted!</h2>
          <p style="font-size: 16px; line-height: 1.6;">
            A new job has been posted that matches your skills!
          </p>
          
          <div style="background-color: #f0f2f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #0a66c2;">${job.title}</h3>
            <p><strong>🏢 Posted by:</strong> ${jobPosterName}</p>
            <p><strong>📍 Location:</strong> ${job.location}</p>
            <p><strong>💰 Budget:</strong> PKR ${job.budget.toLocaleString()}</p>
            <p><strong>🔧 Skills Required:</strong> ${job.skill}</p>
            <p><strong>👥 Workers Needed:</strong> ${job.workersRequired}</p>
            <p><strong>📅 Start Date:</strong> ${new Date(job.startDate).toLocaleDateString()}</p>
            <p><strong>📅 End Date:</strong> ${new Date(job.endDate).toLocaleDateString()}</p>
            <p><strong>⏰ Shift:</strong> ${job.shift}</p>
            <p><strong>📝 Description:</strong></p>
            <p style="background-color: white; padding: 10px; border-radius: 5px; margin: 10px 0;">${job.description}</p>
            <p><strong>📞 Contact:</strong> ${job.contact}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0 20px;">
            <a href="${applyUrl}" 
               style="background-color: #0a66c2; color: white; text-decoration: none; padding: 12px 30px; border-radius: 8px; font-weight: bold; display: inline-block;">
              Apply Now
            </a>
          </div>
        </div>

        <div style="background-color: #f0f2f5; text-align: center; padding: 20px; border-top: 1px solid #e1e4e8;">
          <p style="color: #777777; font-size: 13px; margin: 0;">
            © ${new Date().getFullYear()} Labour Hub. All rights reserved.<br>
            Karachi, Pakistan
          </p>
          <p style="color: #999999; font-size: 11px; margin: 10px 0 0;">
            You're receiving this because you're a registered Labour user on Labour Hub.
          </p>
        </div>
      </div>
    </div>
  `;
}

/**
 * Generate email HTML for job poster confirmation
 */
function getJobPosterConfirmationHTML(job) {
  const logoUrl =
    "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762834364/logo_je7mnb.png";

  return `
    <div style="font-family: 'Segoe UI', sans-serif; background-color: #f5f7fa; padding: 40px 0;">
      <div style="max-width: 600px; background-color: #ffffff; margin: 0 auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        
        <div style="background-color: #0a66c2; padding: 25px 20px; text-align: center;">
          <img src="${logoUrl}" alt="Labour Hub Logo" width="70" height="70" style="border-radius: 50%; border: 2px solid #ffffff; margin-bottom: 10px;">
          <h1 style="color: #ffffff; font-size: 24px; margin: 0;">Labour Hub</h1>
          <p style="color: #ffffff; margin: 5px 0 0;">Job Posted Successfully!</p>
        </div>

        <div style="padding: 30px 25px; color: #333333;">
          <h2 style="color: #0a66c2; font-size: 20px; margin-top: 0;">✅ Job Posted Successfully!</h2>
          <p style="font-size: 16px; line-height: 1.6;">
            Your job "<strong>${job.title}</strong>" has been posted successfully on Labour Hub.
          </p>
          
          <div style="background-color: #f0f2f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin-top: 0; color: #0a66c2;">Job Summary</h3>
            <p><strong>📍 Location:</strong> ${job.location}</p>
            <p><strong>💰 Budget:</strong> PKR ${job.budget.toLocaleString()}</p>
            <p><strong>👥 Workers Needed:</strong> ${job.workersRequired}</p>
            <p><strong>🔧 Skills Required:</strong> ${job.skill}</p>
            <p><strong>📅 Duration:</strong> ${new Date(job.startDate).toLocaleDateString()} - ${new Date(job.endDate).toLocaleDateString()}</p>
          </div>
          
          <p>You will receive <strong>email and push notifications</strong> when workers apply to your job posting.</p>
          
          <div style="text-align: center; margin: 30px 0 20px;">
            <a href="https://labourhub.pk/my-jobs" 
               style="background-color: #0a66c2; color: white; text-decoration: none; padding: 12px 30px; border-radius: 8px; font-weight: bold; display: inline-block;">
              View Your Jobs
            </a>
          </div>
        </div>

        <div style="background-color: #f0f2f5; text-align: center; padding: 20px; border-top: 1px solid #e1e4e8;">
          <p style="color: #777777; font-size: 13px; margin: 0;">
            © ${new Date().getFullYear()} Labour Hub. All rights reserved.<br>
            Karachi, Pakistan
          </p>
        </div>
      </div>
    </div>
  `;
}

/**
 * Generate email HTML for application status update
 */
function getApplicationStatusEmailHTML(job, status, contractorName) {
  const logoUrl =
    "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762834364/logo_je7mnb.png";
  const statusText = status === "accepted" ? "Accepted ✅" : "Rejected ❌";
  const statusColor = status === "accepted" ? "#16a34a" : "#dc2626";
  const message =
    status === "accepted"
      ? "Congratulations! Your application has been accepted. The contractor will contact you shortly."
      : "Unfortunately, your application was not selected for this position. Don't worry, there are many more opportunities available!";

  return `
    <div style="font-family: 'Segoe UI', sans-serif; background-color: #f5f7fa; padding: 40px 0;">
      <div style="max-width: 600px; background-color: #ffffff; margin: 0 auto; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
        
        <div style="background-color: #0a66c2; padding: 25px 20px; text-align: center;">
          <img src="${logoUrl}" alt="Labour Hub Logo" width="70" height="70" style="border-radius: 50%; border: 2px solid #ffffff; margin-bottom: 10px;">
          <h1 style="color: #ffffff; font-size: 24px; margin: 0;">Labour Hub</h1>
          <p style="color: #ffffff; margin: 5px 0 0;">Application Update</p>
        </div>

        <div style="padding: 30px 25px; color: #333333; text-align: center;">
          <h2 style="color: ${statusColor}; font-size: 24px; margin-top: 0;">Application ${statusText}</h2>
          <p style="font-size: 18px; margin: 20px 0;">
            <strong>Job Title:</strong> ${job.title}
          </p>
          <p><strong>Contractor:</strong> ${contractorName}</p>
          <div style="background-color: #f0f2f5; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;">${message}</p>
          </div>
          
          <div style="text-align: center; margin: 30px 0 20px;">
            <a href="https://labourhub.pk/my-applications" 
               style="background-color: #0a66c2; color: white; text-decoration: none; padding: 12px 30px; border-radius: 8px; font-weight: bold; display: inline-block;">
              View My Applications
            </a>
          </div>
        </div>

        <div style="background-color: #f0f2f5; text-align: center; padding: 20px; border-top: 1px solid #e1e4e8;">
          <p style="color: #777777; font-size: 13px; margin: 0;">
            © ${new Date().getFullYear()} Labour Hub. All rights reserved.<br>
            Karachi, Pakistan
          </p>
        </div>
      </div>
    </div>
  `;
}

app.use("/api/chat", chatRoutes);
notification.sendServerStartNotification().catch(console.error);

// ─── Schemas ─────────────────────────────────────────────────────────────────
const userSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true, trim: true, maxlength: 50 },
    lastName: { type: String, required: true, trim: true, maxlength: 50 },
    phone: { type: String, required: true, trim: true },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ["Labour", "Contractor"], default: "Labour" },
    image: {
      type: String,
      default:
        "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762757911/Pngtree_user_profile_avatar_13369988_qdlgmg.png",
    },
    skills: { type: [String], default: [] },
    expoPushToken: { type: String, default: null },
    reviews: [
      {
        reviewerEmail: { type: String, required: true },
        rating: { type: Number, required: true, min: 1, max: 5 },
        feedback: { type: String, trim: true },
        createdAt: { type: Date, default: Date.now },
      },
    ],
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true },
);

const User = mongoose.model("User", userSchema);

const jobSchema = new mongoose.Schema(
  {
    title: String,
    description: String,
    location: String,
    workersRequired: Number,
    skill: String,
    budget: Number,
    contact: String,
    startDate: Date,
    endDate: Date,
    shift: { type: String, default: "Shift A" },
    jobTime: { type: Date, default: Date.now },
    createdBy: {
      userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      firstName: String,
      lastName: String,
      role: String,
      email: String,
    },
    applicants: [
      {
        laborId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        appliedAt: { type: Date, default: Date.now },
        status: {
          type: String,
          enum: ["pending", "accepted", "rejected"],
          default: "pending",
        },
        chatId: { type: mongoose.Schema.Types.ObjectId, ref: "Chat" },
      },
    ],
    noOfWorkersApplied: { type: Number, default: 0 },
  },
  { timestamps: true },
);

const Job = mongoose.model("Job", jobSchema);

const jobApplicationSchema = new mongoose.Schema({
  jobId: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
  contractorEmail: { type: String, required: true },
  labourEmail: { type: String, required: true },
  appliedAt: { type: Date, default: Date.now },
});

const JobApplication = mongoose.model("JobApplication", jobApplicationSchema);
module.exports = JobApplication;

// ─── Profile Image ───────────────────────────────────────────────────────────
app.post(
  "/api/update-profile-image",
  upload.single("image"),
  async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: "Email is required" });
    if (!req.file)
      return res.status(400).json({ message: "No image uploaded" });

    try {
      const imageUrl = req.file.path;
      const user = await User.findOneAndUpdate(
        { email },
        { image: imageUrl },
        { new: true },
      );
      if (!user) return res.status(404).json({ message: "User not found" });
      return res.status(200).json({ message: "Profile image updated", user });
    } catch (err) {
      console.log("Server error:", err);
      res.status(500).json({ message: "Server error" });
    }
  },
);

// ─── Add Review ──────────────────────────────────────────────────────────────
// 🔔 NOTIFICATION: Notify the reviewed user about their new review
app.post("/api/users/:email/review", async (req, res) => {
  const { email } = req.params;
  const { reviewerEmail, rating, feedback, jobTitle } = req.body;

  if (!reviewerEmail || !rating) {
    return res
      .status(400)
      .json({ message: "Reviewer email and rating are required" });
  }

  try {
    const user = await User.findOneAndUpdate(
      { email },
      { $push: { reviews: { reviewerEmail, rating, feedback } } },
      { new: true },
    );

    if (!user) return res.status(404).json({ message: "User not found" });

    // 🔔 Push notification to reviewed user
    if (user.expoPushToken) {
      notification
        .notifyUserAboutNewReview(
          user.expoPushToken,
          reviewerEmail,
          rating,
          jobTitle || null,
        )
        .catch((e) => console.error("Review notification error:", e));
    }

    res.status(200).json({ message: "Review added", user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ─── Get Users ────────────────────────────────────────────────────────────────
app.get("/api/users", async (req, res) => {
  try {
    const { skill, role, q } = req.query;
    let filter = {};
    if (skill) filter.skills = { $regex: skill, $options: "i" };
    if (role) filter.role = role;
    if (q)
      filter.$or = [
        { firstName: { $regex: q, $options: "i" } },
        { lastName: { $regex: q, $options: "i" } },
      ];

    const users = await User.find(filter).select(
      "firstName lastName email phone role image skills",
    );
    const formattedUsers = users.map((user) => ({
      _id: user._id,
      name: `${user.firstName} ${user.lastName}`,
      email: user.email,
      phone: user.phone,
      image: user.image,
      skills: user.skills,
      role: user.role,
      badge: user.role === "Contractor" ? "🟦 Contractor" : "🟩 Labour",
    }));

    res.status(200).json({
      success: true,
      count: formattedUsers.length,
      users: formattedUsers,
    });
  } catch (error) {
    console.error("User Fetch Error:", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

app.get("/api/user/:userId", async (req, res) => {
  try {
    const user = await User.findById(req.params.userId);
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/user/skills/:email", async (req, res) => {
  try {
    const email = req.params.email.toLowerCase().trim();
    const user = await User.findOne({ email });
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    return res.json({
      success: true,
      email: user.email,
      skills: user.skills || [],
    });
  } catch (err) {
    res
      .status(500)
      .json({ success: false, message: "Server error while fetching skills" });
  }
});

app.post("/api/user/:email/skills", async (req, res) => {
  try {
    const email = req.params.email.toLowerCase().trim();
    const { skill } = req.body;
    if (!skill || !skill.trim())
      return res
        .status(400)
        .json({ success: false, message: "Skill is required" });

    const user = await User.findOne({ email });
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    if (user.skills.includes(skill.trim()))
      return res.json({ success: true, message: "Skill already exists" });

    user.skills.push(skill.trim());
    await user.save();
    return res.json({
      success: true,
      message: "Skill added successfully",
      skills: user.skills,
    });
  } catch (err) {
    res
      .status(500)
      .json({ success: false, message: "Server error while adding skill" });
  }
});

app.delete("/api/user/:email/skills/:index", async (req, res) => {
  try {
    const email = req.params.email.toLowerCase().trim();
    const index = parseInt(req.params.index);
    const user = await User.findOne({ email });
    if (!user)
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    if (index < 0 || index >= user.skills.length)
      return res
        .status(400)
        .json({ success: false, message: "Invalid skill index" });

    user.skills.splice(index, 1);
    await user.save();
    return res.json({
      success: true,
      message: "Skill deleted successfully",
      skills: user.skills,
    });
  } catch (err) {
    res
      .status(500)
      .json({ success: false, message: "Server error while deleting skill" });
  }
});

app.get("/api/user-by-email/:email", async (req, res) => {
  try {
    const { email } = req.params;
    const user = await User.findOne({ email }).select(
      "firstName lastName email image role",
    );
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ─── Auth Helpers ─────────────────────────────────────────────────────────────
function validateSignupPayload(payload) {
  const errors = [];
  if (!payload.firstName || String(payload.firstName).trim().length < 2)
    errors.push("First name is required (min 2 characters).");
  if (!payload.lastName || String(payload.lastName).trim().length < 1)
    errors.push("Last name is required.");
  if (!payload.phone || !/^\+?[0-9]{7,15}$/.test(String(payload.phone).trim()))
    errors.push(
      "Phone is required (digits only, 7-15 chars, optional leading +).",
    );
  if (!payload.email || !validator.isEmail(String(payload.email)))
    errors.push("A valid email is required.");
  if (!payload.password || String(payload.password).length < 6)
    errors.push("Password is required (min 6 characters).");
  if (!payload.role || !["Labour", "Contractor"].includes(payload.role))
    errors.push("Role must be either 'Labour' or 'Contractor'.");
  return errors;
}

function signJwt(user) {
  return jwt.sign(
    { sub: user._id.toString(), email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" },
  );
}

// ─── Signup ───────────────────────────────────────────────────────────────────
app.post("/api/signup", async (req, res) => {
  try {
    const { firstName, lastName, phone, email, password, role, expoPushToken } =
      req.body || {};
    const validationErrors = validateSignupPayload({
      firstName,
      lastName,
      phone,
      email,
      password,
      role,
    });
    if (validationErrors.length)
      return res.status(400).json({ errors: validationErrors });

    const normalizedEmail = String(email).trim().toLowerCase();
    const normalizedPhone = String(phone).trim();

    const existing = await User.findOne({ email: normalizedEmail }).lean();
    if (existing)
      return res.status(409).json({ error: "Email already in use." });

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || "10", 10);
    const passwordHash = await bcrypt.hash(password, saltRounds);

    const user = new User({
      firstName: String(firstName).trim(),
      lastName: String(lastName).trim(),
      phone: normalizedPhone,
      email: normalizedEmail,
      passwordHash,
      role,
      expoPushToken: expoPushToken || null,
    });

    await user.save();
    const token = signJwt(user);

    return res.status(201).json({
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        phone: user.phone,
        email: user.email,
        role: user.role,
        createdAt: user.createdAt,
      },
      token,
    });
  } catch (err) {
    console.error("Signup error:", err);
    return res.status(500).json({ error: "Internal server error." });
  }
});

// ─── Login ────────────────────────────────────────────────────────────────────
app.post("/api/login", async (req, res) => {
  try {
    const { email, password, expoPushToken } = req.body || {};
    if (!email || !password)
      return res.status(400).json({ error: "Email and password required." });

    const user = await User.findOne({
      email: String(email).trim().toLowerCase(),
    });
    if (!user) return res.status(401).json({ error: "Invalid credentials." });

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return res.status(401).json({ error: "Invalid credentials." });

    if (expoPushToken) {
      user.expoPushToken = expoPushToken;
      await user.save();
      console.log(`✅ Saved push token for ${email}`);
    }

    const token = signJwt(user);
    return res.json({
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        role: user.role,
      },
      token,
    });
  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ error: "Internal server error." });
  }
});

app.get("/api/me", async (req, res) => {
  try {
    const auth = req.headers.authorization;
    if (!auth || !auth.startsWith("Bearer "))
      return res.status(401).json({ error: "Missing token." });
    const decoded = jwt.verify(auth.slice(7), process.env.JWT_SECRET);
    const user = await User.findById(decoded.sub).lean();
    if (!user) return res.status(404).json({ error: "User not found." });
    return res.json({
      user: {
        id: user._id,
        email: user.email,
        firstName: user.firstName,
        role: user.role,
      },
    });
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token." });
  }
});

// ─── Password Reset ───────────────────────────────────────────────────────────
app.post("/api/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required." });
    const user = await User.findOne({
      email: String(email).trim().toLowerCase(),
    });
    if (!user)
      return res
        .status(404)
        .json({ error: "No account found with this email." });
    return res
      .status(200)
      .json({ message: "User found. Proceed to reset password." });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error." });
  }
});

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID,
  process.env.TWILIO_AUTH_TOKEN,
);
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

app.post("/api/reset-password", async (req, res) => {
  try {
    const { email, newPassword } = req.body;
    if (!email || !newPassword)
      return res
        .status(400)
        .json({ error: "Email and new password are required." });

    const user = await User.findOne({
      email: String(email).trim().toLowerCase(),
    });
    if (!user) return res.status(404).json({ error: "User not found." });

    const isSame = await bcrypt.compare(newPassword, user.passwordHash);
    if (isSame)
      return res.status(400).json({
        error: "New password must be different from your old password.",
      });

    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || "10", 10);
    user.passwordHash = await bcrypt.hash(newPassword, saltRounds);
    await user.save();

    const logoUrl =
      "https://res.cloudinary.com/dh7kv5dzy/image/upload/v1762834364/logo_je7mnb.png";
    try {
      await sgMail.send({
        to: user.email,
        from: process.env.SENDGRID_VERIFIED_SENDER,
        subject: "Labour Hub - Password Changed Successfully",
        html: `
          <div style="font-family:'Segoe UI',sans-serif;background:#f5f7fa;padding:40px 0;">
            <div style="max-width:600px;background:#fff;margin:0 auto;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,.1);">
              <div style="background:#0a66c2;padding:25px 20px;text-align:center;">
                <img src="${logoUrl}" alt="Labour Hub Logo" width="70" height="70" style="border-radius:50%;border:2px solid #fff;margin-bottom:10px;">
                <h1 style="color:#fff;font-size:24px;margin:0;">Labour Hub</h1>
              </div>
              <div style="padding:30px 25px;color:#333;">
                <h2 style="color:#0a66c2;">Password Changed Successfully</h2>
                <p>Dear <strong>${user.email}</strong>,<br><br>Your password has been changed successfully.</p>
                <p>If this wasn't you, please contact support immediately.</p>
                <div style="text-align:center;margin-top:30px;">
                  <a href="https://labourhub.pk/login" style="background:#0a66c2;color:#fff;text-decoration:none;padding:12px 25px;border-radius:8px;font-weight:bold;">Go to Login</a>
                </div>
              </div>
              <div style="background:#f0f2f5;text-align:center;padding:20px;border-top:1px solid #e1e4e8;">
                <p style="color:#777;font-size:13px;margin:0;">&copy; ${new Date().getFullYear()} Labour Hub. Karachi, Pakistan</p>
              </div>
            </div>
          </div>`,
      });
      console.log(`✅ Password reset email sent to ${user.email}`);
    } catch (err) {
      console.error(
        "Email send failed:",
        err.response ? err.response.body : err,
      );
    }

    return res.status(200).json({ message: "Password reset successfully!" });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error." });
  }
});

const DEFAULT_IMAGE =
  "https://png.pngtree.com/png-vector/20231019/ourmid/pngtree-user-profile-avatar-png-image_10211467.png";

app.get("/api/user/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select(
      "firstName lastName role email image",
    );
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json({
      firstName: user.firstName || "",
      lastName: user.lastName || "",
      role: user.role || "",
      email: user.email || "",
      image:
        user.image && user.image.trim() !== "" ? user.image : DEFAULT_IMAGE,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ─── Jobs ─────────────────────────────────────────────────────────────────────

// ── POST /api/jobs/apply/:jobId  (apply via Job.applicants array)
// 🔔 NOTIFICATION: Notify the contractor when a labour applies
app.post("/api/jobs/apply/:jobId", async (req, res) => {
  const { jobId } = req.params;
  const { labourId, labourEmail } = req.body;

  try {
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const alreadyApplied = job.applicants.some(
      (app) => app.laborId && app.laborId.toString() === labourId,
    );
    if (alreadyApplied)
      return res.status(400).json({ message: "Already applied" });

    job.applicants.push({
      laborId: labourId,
      appliedAt: new Date(),
      status: "pending",
    });
    job.noOfWorkersApplied = job.applicants.length;
    await job.save();

    await JobApplication.create({
      jobId: job._id,
      contractorEmail: job.createdBy.email,
      labourEmail,
    });

    // 🔔 Fetch labour info & contractor token, then notify contractor
    try {
      const [labour, contractor] = await Promise.all([
        User.findById(labourId).select("firstName lastName email"),
        User.findOne({ email: job.createdBy.email }).select("expoPushToken"),
      ]);

      if (contractor?.expoPushToken && labour) {
        await notification.notifyContractorAboutApplication(
          contractor.expoPushToken,
          labour,
          job,
        );
      }
    } catch (notifErr) {
      console.error("❌ Apply notification error:", notifErr);
    }

    res.status(200).json({ message: "Applied successfully", job });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
});

// ── POST /api/jobs  (create job)
// 🔔 NOTIFICATION: Notify all Labour users about new job
// Create a new job (UPDATED with SMTP email notifications)
app.post("/api/jobs", async (req, res) => {
  try {
    const {
      title,
      description,
      location,
      workersRequired,
      skill,
      budget,
      contact,
      startDate,
      endDate,
      createdBy,
      shift,
      jobTime,
    } = req.body;

    if (
      !title ||
      !description ||
      !location ||
      !workersRequired ||
      !skill ||
      !budget ||
      !contact ||
      !startDate ||
      !endDate
    ) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const job = new Job({
      title,
      description,
      location,
      workersRequired,
      skill,
      budget,
      contact,
      startDate,
      endDate,
      shift: shift || "Shift A",
      jobTime: jobTime || new Date(),
      createdBy: {
        userId: createdBy.userId,
        firstName: createdBy.firstName,
        lastName: createdBy.lastName,
        role: createdBy.role,
        email: createdBy.email,
      },
    });

    await job.save();

    // ============================================
    // SEND NOTIFICATIONS TO ALL LABOUR USERS
    // ============================================
    let notificationResult = { successCount: 0, failCount: 0 };
    let emailResult = { successCount: 0, failCount: 0 };

    try {
      // Get all Labour users
      const labourUsers = await User.find({
        role: "Labour",
      }).select("expoPushToken firstName lastName email");

      console.log(`📱 Found ${labourUsers.length} labour users`);

      if (labourUsers.length > 0) {
        // Send push notifications (only to those with tokens)
        const usersWithTokens = labourUsers.filter((u) => u.expoPushToken);
        if (usersWithTokens.length > 0) {
          notificationResult = await notification.notifyLabourUsersAboutNewJob(
            usersWithTokens,
            job,
          );
          console.log(
            `📊 Push Notification Summary: ${notificationResult.successCount} sent, ${notificationResult.failCount} failed`,
          );
        }

        // Send email notifications to ALL labour users
        console.log(
          `\n📧 Sending email notifications to ${labourUsers.length} labour users...`,
        );
        const jobPosterName =
          `${createdBy.firstName} ${createdBy.lastName}`.trim();

        emailResult = await sendBulkEmails(
          labourUsers,
          `🔔 New Job Alert: ${job.title} - Labour Hub`,
          (user) => getNewJobEmailHTML(job, jobPosterName),
        );

        console.log(
          `📊 Email Summary: ${emailResult.successCount} sent, ${emailResult.failCount} failed`,
        );
      } else {
        console.log("⚠️ No labour users found.");
      }

      // Send confirmation email to job poster
      const poster = await User.findById(createdBy.userId);
      if (poster && poster.email) {
        await sendSingleEmail(
          poster.email,
          `✅ Job Posted Successfully: ${job.title}`,
          getJobPosterConfirmationHTML(job),
        );
        console.log(
          `✅ Confirmation email sent to job poster: ${poster.email}`,
        );
      }
    } catch (notifError) {
      console.error("❌ Notification error:", notifError);
    }

    return res.status(201).json({
      message: "Job created successfully",
      job,
      pushNotificationsSent: notificationResult.successCount,
      emailsSent: emailResult.successCount,
    });
  } catch (err) {
    console.error("Error creating job:", err);
    return res.status(500).json({ message: "Server error" });
  }
});

// ── PUT /api/jobs/:jobId/applicants/:labourId/status
// 🔔 NOTIFICATION: Notify the labour about acceptance or rejection
// Update application status with SMTP email
app.put("/api/jobs/:jobId/applicants/:labourId/status", async (req, res) => {
  const { jobId, labourId } = req.params;
  const { status } = req.body;

  if (!["accepted", "rejected"].includes(status)) {
    return res
      .status(400)
      .json({ message: "Status must be 'accepted' or 'rejected'" });
  }

  try {
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const applicant = job.applicants.find(
      (a) => a.laborId.toString() === labourId,
    );
    if (!applicant)
      return res
        .status(404)
        .json({ message: "Applicant not found on this job" });

    applicant.status = status;
    await job.save();

    // Get labour info for email
    const labour = await User.findById(labourId).select(
      "expoPushToken firstName lastName email",
    );
    const contractorName = `${job.createdBy.firstName} ${job.createdBy.lastName}`;

    // Send push notification
    if (labour?.expoPushToken) {
      await notification
        .notifyLabourAboutApplicationStatus(labour.expoPushToken, job, status)
        .catch((e) => console.error("Push notification error:", e));
    }

    // Send email notification via SMTP
    if (labour?.email) {
      const emailSent = await sendSingleEmail(
        labour.email,
        `Application ${status === "accepted" ? "Accepted ✅" : "Rejected ❌"}: ${job.title}`,
        getApplicationStatusEmailHTML(job, status, contractorName),
      );
      console.log(
        `Status email ${emailSent ? "sent" : "failed"} to ${labour.email}`,
      );
    }

    res.status(200).json({
      message: `Applicant ${status} successfully`,
      job,
      notifications: {
        push: !!labour?.expoPushToken,
        email: !!labour?.email,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// ── Update push token
app.post("/api/update-push-token", async (req, res) => {
  try {
    const { email, expoPushToken } = req.body;
    if (!email || !expoPushToken)
      return res.status(400).json({ error: "Email and token required" });

    const user = await User.findOneAndUpdate(
      { email: email.toLowerCase().trim() },
      { expoPushToken },
      { new: true },
    );
    if (!user) return res.status(404).json({ error: "User not found" });

    console.log(`✅ Updated push token for ${email}`);
    res.json({ success: true, message: "Token updated" });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

app.get("/api/alljobs", async (req, res) => {
  try {
    const jobs = await Job.find().sort({ createdAt: -1 });
    res.status(200).json(jobs);
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

app.post("/api/manual-add-token", async (req, res) => {
  try {
    const { email, expoPushToken } = req.body;
    if (!email || !expoPushToken)
      return res.status(400).json({ error: "Email and token required" });

    const user = await User.findOneAndUpdate(
      { email: email.toLowerCase().trim(), role: "Labour" },
      { expoPushToken },
      { new: true },
    );
    if (!user)
      return res
        .status(404)
        .json({ error: "Labour user not found with this email" });

    res.json({
      success: true,
      message: `Token added for ${email}`,
      user: { email: user.email, role: user.role, hasToken: true },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/debug-users", async (req, res) => {
  try {
    const allUsers = await User.find({}).select(
      "email role expoPushToken createdAt",
    );
    const labourUsers = allUsers.filter((u) => u.role === "Labour");
    res.json({
      totalUsers: allUsers.length,
      usersWithTokens: allUsers.filter((u) => u.expoPushToken).length,
      labourUsers: labourUsers.length,
      labourWithTokens: labourUsers.filter((u) => u.expoPushToken).length,
      details: allUsers.map((u) => ({
        email: u.email,
        role: u.role,
        hasToken: !!u.expoPushToken,
        tokenPreview: u.expoPushToken
          ? u.expoPushToken.substring(0, 30) + "..."
          : null,
        createdAt: u.createdAt,
      })),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/my-jobs-email/:email", async (req, res) => {
  const { email } = req.params;
  try {
    const jobs = await Job.find({ "createdBy.email": email }).sort({
      createdAt: -1,
    });
    res.status(200).json(jobs);
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

app.get("/api/filter", async (req, res) => {
  try {
    const {
      userEmail,
      location,
      skill,
      startDate,
      endDate,
      minBudget,
      maxBudget,
    } = req.query;
    const query = {};
    if (userEmail) query["createdBy.email"] = { $ne: userEmail };
    if (location) query.location = location;
    if (skill) query.skill = skill;
    if (startDate && endDate) {
      query.startDate = { $gte: new Date(startDate) };
      query.endDate = { $lte: new Date(endDate) };
    } else if (startDate) query.startDate = { $gte: new Date(startDate) };
    else if (endDate) query.endDate = { $lte: new Date(endDate) };
    if (minBudget || maxBudget) {
      query.budget = {};
      if (minBudget) query.budget.$gte = Number(minBudget);
      if (maxBudget) query.budget.$lte = Number(maxBudget);
    }
    const jobs = await Job.find(query).sort({ createdAt: -1 });
    const cities = await Job.distinct("location");
    const skillsList = await Job.distinct("skill");
    res.status(200).json({ filters: { cities, skills: skillsList }, jobs });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/profile/:email", async (req, res) => {
  try {
    const { email } = req.params;
    const user = await User.findOne({ email: email.trim().toLowerCase() })
      .select("firstName lastName role email image createdAt reviews")
      .lean();

    if (!user) return res.status(404).json({ message: "User not found" });
    user.image = user.image?.trim() || DEFAULT_IMAGE;

    const reviews = user.reviews || [];
    const totalReviews = reviews.length;
    const averageRating =
      totalReviews > 0
        ? (
            reviews.reduce((sum, r) => sum + r.rating, 0) / totalReviews
          ).toFixed(1)
        : 0;

    let jobsCreated = [],
      jobsApplied = [],
      totalApplicantsOnJobs = 0;

    if (user.role === "Contractor") {
      jobsCreated = await Job.find({ "createdBy.email": email }).lean();
      totalApplicantsOnJobs = jobsCreated.reduce(
        (acc, job) => acc + (job.applicants?.length || 0),
        0,
      );
    } else {
      const applications = await Job.find({
        "applicants.laborId": user._id,
      }).lean();
      jobsApplied = applications.map((job) => {
        const applicant = job.applicants.find(
          (a) => a.laborId.toString() === user._id.toString(),
        );
        return {
          jobId: job._id,
          title: job.title,
          status: applicant?.status || "pending",
          appliedAt: applicant?.appliedAt || null,
          contractor: job.createdBy,
        };
      });
    }

    res.json({
      user: { ...user, averageRating, totalReviews },
      reviews,
      stats: {
        totalJobsPosted: jobsCreated.length,
        totalJobsApplied: jobsApplied.length,
        totalApplicantsOnJobs,
      },
      jobsCreated,
      jobsApplied,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// Add this test endpoint after the email functions
app.get("/api/test-email", async (req, res) => {
  try {
    const testEmail = req.query.email || process.env.test_email;

    const result = await sendSingleEmail(
      testEmail,
      "🔔 Labour Hub - SMTP Test Email",
      `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color: #0a66c2;">✅ SMTP Test Successful!</h2>
        <p>If you're reading this, your SMTP email configuration is working perfectly.</p>
        <p>Time: ${new Date().toLocaleString()}</p>
        <hr>
        <p style="color: #666; font-size: 12px;">Labour Hub Notification System</p>
      </div>
      `,
    );

    res.json({
      success: result,
      message: result
        ? "Test email sent successfully"
        : "Failed to send test email",
      sentTo: testEmail,
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get("/api/jobs/user/:email", async (req, res) => {
  try {
    const { email } = req.params;
    const user = await User.findOne({
      email: email.trim().toLowerCase(),
    }).lean();
    if (!user) return res.status(404).json({ message: "User not found" });

    const jobsCreated = await Job.find({ "createdBy.email": email })
      .sort({ createdAt: -1 })
      .lean();
    const jobApplications = await JobApplication.find({
      labourEmail: email,
    }).lean();

    const jobsApplied = [];
    for (const app of jobApplications) {
      const job = await Job.findById(app.jobId).lean();
      if (!job) continue;
      jobsApplied.push({
        jobId: job._id,
        title: job.title,
        status: "pending",
        appliedAt: app.appliedAt,
        contractor: {
          firstName: job.createdBy.firstName,
          lastName: job.createdBy.lastName,
          email: job.createdBy.email,
          role: job.createdBy.role,
          image: job.createdBy.image || DEFAULT_IMAGE,
        },
      });
    }

    res.status(200).json({
      user: {
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        image: user.image || DEFAULT_IMAGE,
      },
      stats: {
        totalJobsPosted: jobsCreated.length,
        totalJobsApplied: jobsApplied.length,
      },
      jobsCreated,
      jobsApplied,
    });
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

app.get("/api/responses-by-contractor/:email", async (req, res) => {
  try {
    const { email } = req.params;
    const applications = await JobApplication.find({
      contractorEmail: email,
    }).lean();
    if (!applications || applications.length === 0)
      return res.status(404).json({ message: "No responses found" });

    const results = [];
    for (const app of applications) {
      const job = await Job.findById(app.jobId).lean();
      if (!job) continue;
      const labour = await User.findOne({ email: app.labourEmail }).lean();
      results.push({
        applicationId: app._id,
        jobId: job._id,
        jobTitle: job.title,
        jobDescription: job.description,
        location: job.location,
        workersRequired: job.workersRequired,
        appliedAt: app.appliedAt,
        labour: {
          labourId: labour?._id || null,
          firstName: labour?.firstName || "Unknown",
          lastName: labour?.lastName || "Unknown",
          email: labour?.email || app.labourEmail,
          role: labour?.role || "Labour",
          image: labour?.image || DEFAULT_IMAGE,
        },
      });
    }

    res.status(200).json({
      contractorEmail: email,
      totalResponses: results.length,
      responses: results,
    });
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

app.get("/api/search-jobs", async (req, res) => {
  try {
    const { skill, name } = req.query;
    const query = {};
    if (skill && skill.trim() !== "")
      query.skill = { $regex: new RegExp(skill, "i") };
    if (name && name.trim() !== "")
      query.title = { $regex: new RegExp(name, "i") };
    const jobs = await Job.find(query).sort({ createdAt: -1 });
    return res.json({ success: true, count: jobs.length, jobs });
  } catch (err) {
    res
      .status(500)
      .json({ success: false, message: "Server error while searching jobs" });
  }
});

// ── POST /api/apply/:jobId  (apply via JobApplication collection)
// 🔔 NOTIFICATION: Notify the contractor when a labour applies
app.post("/api/apply/:jobId", async (req, res) => {
  try {
    const { jobId } = req.params;
    const { labourEmail } = req.body;
    if (!labourEmail)
      return res.status(400).json({ message: "Labour email is required" });

    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const exists = await JobApplication.findOne({ jobId, labourEmail });
    if (exists) return res.status(400).json({ message: "Already applied" });

    const application = new JobApplication({
      jobId,
      contractorEmail: job.createdBy.email,
      labourEmail,
    });
    await application.save();

    job.noOfWorkersApplied = (job.noOfWorkersApplied || 0) + 1;
    await job.save();

    // 🔔 Notify contractor about the new application
    try {
      const [labour, contractor] = await Promise.all([
        User.findOne({ email: labourEmail }).select("firstName lastName email"),
        User.findOne({ email: job.createdBy.email }).select("expoPushToken"),
      ]);

      if (contractor?.expoPushToken && labour) {
        await notification.notifyContractorAboutApplication(
          contractor.expoPushToken,
          labour,
          job,
        );
      }
    } catch (notifErr) {
      console.error("❌ Apply notification error:", notifErr);
    }

    res.status(200).json({ success: true, application });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/get-user-by-email/:email", async (req, res) => {
  try {
    const user = await User.findOne({ email: req.params.email }).lean();
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json({ id: user._id });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/check-application/:jobId", async (req, res) => {
  try {
    const { jobId } = req.params;
    const userEmail = req.query.email?.trim().toLowerCase();
    if (!userEmail)
      return res.status(400).json({ message: "Email is required" });

    const application = await JobApplication.findOne({
      jobId,
      labourEmail: userEmail,
    });
    res.json({
      applied: !!application,
      message: application ? "User already applied" : "User has not applied",
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ─── Industry ─────────────────────────────────────────────────────────────────
const industrySchema = new mongoose.Schema(
  {
    industry: { type: String, required: true },
    owner: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    address: { type: String, required: true },
    textileType: { type: String, required: true },
    password: { type: String, required: true },
    active: { type: Boolean, default: false },
    expoPushToken: { type: String, default: null }, // 🔔 Added for push notifications
  },
  { timestamps: true },
);

const Industry = mongoose.model("Industry", industrySchema);

app.post("/api/industries", async (req, res) => {
  try {
    const { industry, owner, email, phone, address, textileType, password } =
      req.body;
    if (
      !industry ||
      !owner ||
      !email ||
      !phone ||
      !address ||
      !textileType ||
      !password
    )
      return res.status(400).json({ message: "All fields are required" });
    if (!validator.isEmail(email))
      return res.status(400).json({ message: "Invalid email format" });
    if (password.length < 8)
      return res
        .status(400)
        .json({ message: "Password must be at least 8 characters" });

    const existing = await Industry.findOne({ email });
    if (existing)
      return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newIndustry = await Industry.create({
      industry,
      owner,
      email,
      phone,
      address,
      textileType,
      password: hashedPassword,
    });
    res.status(201).json({
      message: "Industry registered successfully",
      industry: newIndustry,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// 🔔 Industry login — also saves expoPushToken
app.post("/api/industries/login", async (req, res) => {
  try {
    const { email, password, expoPushToken } = req.body;
    if (!email || !password)
      return res
        .status(400)
        .json({ message: "Email and password are required" });
    if (!validator.isEmail(email))
      return res.status(400).json({ message: "Invalid email format" });

    const industry = await Industry.findOne({ email });
    if (!industry)
      return res.status(400).json({ message: "Invalid credentials" });

    const isMatch = await bcrypt.compare(password, industry.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid credentials" });

    // 🔔 Store push token
    if (expoPushToken) {
      industry.expoPushToken = expoPushToken;
      await industry.save();
      console.log(`✅ Saved industry push token for ${email}`);
    }

    const token = jwt.sign(
      { id: industry._id, email: industry.email },
      "YOUR_SECRET_KEY",
      { expiresIn: "7d" },
    );
    res.status(200).json({
      message: "Login successful",
      email: industry.email,
      token,
      active: industry.active,
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/industries/all", async (req, res) => {
  try {
    const { email, search } = req.query;
    let query = { active: true, email: { $ne: email } };
    if (search) query.industry = { $regex: search, $options: "i" };
    const industries = await Industry.find(query).select(
      "industry email address textileType",
    );
    res.status(200).json(industries);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/industries/profile", async (req, res) => {
  try {
    const { email } = req.query;
    if (!email || typeof email !== "string")
      return res.status(400).json({ message: "Email is required" });
    const industry = await Industry.findOne({ email }).select("-password");
    if (!industry)
      return res.status(404).json({ message: "Industry not found" });
    res.status(200).json(industry);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// 🔔 Update industry push token
app.post("/api/industries/update-push-token", async (req, res) => {
  try {
    const { email, expoPushToken } = req.body;
    if (!email || !expoPushToken)
      return res.status(400).json({ error: "Email and token required" });

    const industry = await Industry.findOneAndUpdate(
      { email: email.toLowerCase().trim() },
      { expoPushToken },
      { new: true },
    );
    if (!industry) return res.status(404).json({ error: "Industry not found" });

    console.log(`✅ Updated push token for industry ${email}`);
    res.json({ success: true, message: "Token updated" });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});

// ─── Borrow ───────────────────────────────────────────────────────────────────
const borrowSchema = new mongoose.Schema(
  {
    fromIndustryEmail: { type: String, required: true },
    toIndustryEmail: { type: String, required: true },
    labourRequired: Number,
    skills: String,
    description: String,
    date: String,
    time: String,
    location: String,
    status: { type: String, default: "Pending" },
  },
  { timestamps: true },
);

const Borrow = mongoose.model("Borrow", borrowSchema);

// ── POST /api/borrow
// 🔔 NOTIFICATION: Notify the target industry about the borrow request
app.post("/api/borrow", async (req, res) => {
  try {
    const borrow = await Borrow.create(req.body);
    res.status(201).json({ message: "Borrow request sent", borrow });

    // Run email + push notification after response
    const {
      toIndustryEmail,
      fromIndustryEmail,
      labourRequired,
      skills,
      description,
      fromDate,
      toDate,
      shift,
      shiftTime,
      location,
    } = req.body;

    if (!toIndustryEmail) {
      console.error("❌ toIndustryEmail missing");
      return;
    }

    // 🔔 Push notification to target industry
    try {
      const targetIndustry = await Industry.findOne({ email: toIndustryEmail });
      if (targetIndustry?.expoPushToken) {
        await notification.notifyIndustryAboutBorrowRequest(
          targetIndustry.expoPushToken,
          fromIndustryEmail,
          borrow,
        );
      }
    } catch (notifErr) {
      console.error("❌ Borrow push notification error:", notifErr);
    }

    // Email
    const msg = {
      to: toIndustryEmail,
      from: process.env.SENDGRID_VERIFIED_SENDER,
      subject: "Labour Hub - New Labour Borrow Request",
      html: `
      <div style="font-family:'Segoe UI',sans-serif;background:#f5f7fa;padding:40px 0;">
        <div style="max-width:620px;margin:auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 10px 25px rgba(0,0,0,.12)">
          <div style="background:linear-gradient(135deg,#0a66c2,#004182);padding:26px;text-align:center;">
            <h1 style="color:#fff;margin:0;">Labour Hub</h1>
            <p style="color:#dbeafe;margin-top:6px;">New Borrow Request</p>
          </div>
          <div style="padding:30px;color:#1f2937;">
            <p>You have received a <strong>new labour borrow request</strong> from <strong>${fromIndustryEmail}</strong>.</p>
            <div style="margin-top:20px;background:#f9fafb;padding:20px;border-radius:12px;border:1px solid #e5e7eb;">
              <table width="100%" style="font-size:14px;">
                <tr><td>Labour Required</td><td><strong>${labourRequired}</strong></td></tr>
                <tr><td>Skills</td><td><strong>${skills}</strong></td></tr>
                <tr><td>Duration</td><td>${fromDate} → ${toDate}</td></tr>
                <tr><td>Shift</td><td>${shift} (${shiftTime})</td></tr>
                <tr><td>Location</td><td>${location}</td></tr>
                <tr><td>Description</td><td>${description}</td></tr>
              </table>
            </div>
            <div style="text-align:center;margin-top:30px;">
              <a href="https://labourhub.pk/dashboard" style="background:#0a66c2;color:#fff;padding:12px 28px;border-radius:10px;text-decoration:none;font-weight:600;">View Request</a>
            </div>
          </div>
          <div style="background:#f3f4f6;padding:18px;text-align:center;font-size:13px;color:#6b7280;">© ${new Date().getFullYear()} Labour Hub · Karachi, Pakistan</div>
        </div>
      </div>`,
    };
    await sgMail.send(msg);
    console.log("✅ Borrow request email sent to", toIndustryEmail);
  } catch (err) {
    console.error("❌ Borrow API error:", err);
  }
});

app.get("/api/my-borrows/:email", async (req, res) => {
  try {
    const myBorrows = await Borrow.find({
      fromIndustryEmail: req.params.email,
    });
    if (!myBorrows.length)
      return res.status(404).json({ message: "No borrow records found." });
    res.status(200).json(myBorrows);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

app.get("/api/incoming-borrows/:email", async (req, res) => {
  try {
    const incomingBorrows = await Borrow.find({
      toIndustryEmail: req.params.email,
    });
    if (!incomingBorrows.length)
      return res.status(404).json({ message: "No incoming requests." });
    res.status(200).json(incomingBorrows);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ── POST /api/approve-borrow/:id
// 🔔 NOTIFICATION: Notify the requesting industry about approval
app.post("/api/approve-borrow/:id", async (req, res) => {
  try {
    const borrow = await Borrow.findById(req.params.id);
    if (!borrow)
      return res.status(404).json({ message: "Borrow request not found." });

    borrow.status = "Approved";
    await borrow.save();

    // 🔔 Push notification to the requesting industry
    try {
      const requesterIndustry = await Industry.findOne({
        email: borrow.fromIndustryEmail,
      });
      if (requesterIndustry?.expoPushToken) {
        await notification.notifyIndustryAboutBorrowApproval(
          requesterIndustry.expoPushToken,
          borrow,
        );
      }
    } catch (notifErr) {
      console.error("❌ Borrow approval push error:", notifErr);
    }

    // Email
    if (borrow.fromIndustryEmail && process.env.SENDGRID_VERIFIED_SENDER) {
      try {
        await sgMail.send({
          to: borrow.fromIndustryEmail,
          from: process.env.SENDGRID_VERIFIED_SENDER,
          subject: "Labour Hub - Borrow Request Approved",
          html: `
          <div style="font-family:'Segoe UI',sans-serif;background:#f5f7fa;padding:40px 0;">
            <div style="max-width:620px;margin:auto;background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 10px 25px rgba(0,0,0,.12)">
              <div style="background:linear-gradient(135deg,#0a66c2,#004182);padding:26px;text-align:center;">
                <h1 style="color:#fff;margin:0;">Labour Hub</h1>
                <p style="color:#dbeafe;margin-top:6px;">Borrow Request Approved</p>
              </div>
              <div style="padding:30px;color:#1f2937;">
                <p>Your borrow request to <strong>${borrow.toIndustryEmail}</strong> has been <strong>approved</strong>.</p>
                <div style="margin-top:20px;background:#f9fafb;padding:20px;border-radius:12px;border:1px solid #e5e7eb;">
                  <table width="100%" style="font-size:14px;">
                    <tr><td>Labour Required</td><td><strong>${borrow.labourRequired}</strong></td></tr>
                    <tr><td>Skills</td><td><strong>${borrow.skills}</strong></td></tr>
                    <tr><td>Date</td><td>${borrow.date}</td></tr>
                    <tr><td>Time</td><td>${borrow.time}</td></tr>
                    <tr><td>Location</td><td>${borrow.location}</td></tr>
                    <tr><td>Description</td><td>${borrow.description}</td></tr>
                  </table>
                </div>
              </div>
              <div style="background:#f3f4f6;padding:18px;text-align:center;font-size:13px;color:#6b7280;">© ${new Date().getFullYear()} Labour Hub · Karachi, Pakistan</div>
            </div>
          </div>`,
        });
        console.log("✅ Approval email sent to", borrow.fromIndustryEmail);
      } catch (emailErr) {
        console.error("⚠️ Email failed:", emailErr.message);
      }
    }

    res.status(200).json({ message: "Borrow request approved", borrow });
  } catch (err) {
    console.error("❌ Approve borrow error:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ─── Admin Panel ──────────────────────────────────────────────────────────────
app.post("/api/admin/industry-toggle/:id", async (req, res) => {
  try {
    const industry = await Industry.findById(req.params.id);
    if (!industry) return res.status(404).json({ error: "Industry not found" });
    industry.active = !industry.active;
    await industry.save();
    res.redirect("/api/admin");
  } catch (err) {
    res.status(500).send("Server error");
  }
});

app.get("/api/admin", async (req, res) => {
  try {
    const users = await User.find().lean();
    const jobs = await Job.find().lean();
    const applications = await JobApplication.find().lean();
    const industries = await Industry.find().lean();
    const borrows = await Borrow.find().lean();

    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
<title>Labour Hub | Admin Panel</title>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<style>
  :root {
    --primary: #0a66c2;
    --primary-dark: #004182;
    --primary-light: #e8f1fc;
    --bg: #f4f6fb;
    --card-bg: #ffffff;
    --text: #1f2937;
    --muted: #6b7280;
    --border: #e5e7eb;
    --green: #16a34a;
    --red: #dc2626;
    --gray: #6b7280;
    --radius: 14px;
    --shadow: 0 8px 24px rgba(10, 102, 194, 0.08);
    --shadow-hover: 0 12px 32px rgba(10, 102, 194, 0.16);
  }

  * { box-sizing: border-box; }

  body {
    font-family: "Segoe UI", "Inter", system-ui, sans-serif;
    background: linear-gradient(180deg, #eef3fb 0%, #f4f6fb 100%);
    margin: 0;
    padding: 28px;
    color: var(--text);
    animation: fadeInPage 0.5s ease;
  }

  @keyframes fadeInPage {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes slideUp {
    from { opacity: 0; transform: translateY(16px); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes rowIn {
    from { opacity: 0; transform: translateX(-6px); }
    to { opacity: 1; transform: translateX(0); }
  }

  @keyframes pulseGlow {
    0%, 100% { box-shadow: 0 0 0 0 rgba(10,102,194,0.25); }
    50% { box-shadow: 0 0 0 6px rgba(10,102,194,0); }
  }

  /* ─── Header ─── */
  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 16px;
    background: linear-gradient(135deg, var(--primary), var(--primary-dark));
    padding: 28px 32px;
    border-radius: var(--radius);
    color: #fff;
    box-shadow: var(--shadow);
    animation: slideUp 0.5s ease;
    margin-bottom: 26px;
  }
  .header h1 {
    margin: 0;
    font-size: 26px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .header p {
    margin: 4px 0 0;
    color: #dbeafe;
    font-size: 14px;
  }
  .header .live-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #4ade80;
    display: inline-block;
    animation: pulseGlow 1.8s infinite;
  }
  .header .timestamp {
    font-size: 13px;
    color: #dbeafe;
    text-align: right;
  }

  /* ─── Stats ─── */
  .stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin-bottom: 30px;
  }
  .stat-card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 20px 22px;
    box-shadow: var(--shadow);
    transition: transform 0.25s ease, box-shadow 0.25s ease;
    animation: slideUp 0.5s ease backwards;
    border: 1px solid var(--border);
  }
  .stat-card:nth-child(1) { animation-delay: 0.05s; }
  .stat-card:nth-child(2) { animation-delay: 0.1s; }
  .stat-card:nth-child(3) { animation-delay: 0.15s; }
  .stat-card:nth-child(4) { animation-delay: 0.2s; }
  .stat-card:nth-child(5) { animation-delay: 0.25s; }
  .stat-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-hover);
  }
  .stat-card .label {
    font-size: 13px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 0.04em;
    margin-bottom: 6px;
  }
  .stat-card .value {
    font-size: 30px;
    font-weight: 700;
    color: var(--primary);
  }

  /* ─── Section / Card ─── */
  .section {
    background: var(--card-bg);
    border-radius: var(--radius);
    box-shadow: var(--shadow);
    margin-bottom: 30px;
    overflow: hidden;
    animation: slideUp 0.55s ease backwards;
    border: 1px solid var(--border);
  }
  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 12px;
    padding: 18px 22px;
    border-bottom: 1px solid var(--border);
    background: var(--primary-light);
  }
  .section-header h2 {
    margin: 0;
    font-size: 17px;
    color: var(--primary-dark);
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .count-badge {
    background: var(--primary);
    color: #fff;
    font-size: 12px;
    padding: 2px 10px;
    border-radius: 999px;
    font-weight: 600;
  }

  .search-box {
    position: relative;
  }
  .search-box input {
    padding: 8px 14px 8px 34px;
    border-radius: 999px;
    border: 1px solid var(--border);
    font-size: 13px;
    width: 220px;
    outline: none;
    transition: box-shadow 0.2s ease, border-color 0.2s ease, width 0.2s ease;
    background: #fff url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="%236b7280" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.398 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg>') no-repeat 12px center;
  }
  .search-box input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(10,102,194,0.15);
    width: 260px;
  }

  /* ─── Table scroll wrapper ─── */
  .table-scroll {
    max-height: 420px;
    overflow-y: auto;
    overflow-x: auto;
  }
  .table-scroll::-webkit-scrollbar {
    width: 10px;
    height: 10px;
  }
  .table-scroll::-webkit-scrollbar-track {
    background: #f1f4f9;
  }
  .table-scroll::-webkit-scrollbar-thumb {
    background: linear-gradient(180deg, var(--primary), var(--primary-dark));
    border-radius: 10px;
    border: 2px solid #f1f4f9;
  }
  .table-scroll::-webkit-scrollbar-thumb:hover {
    background: var(--primary-dark);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    min-width: 640px;
  }
  thead th {
    position: sticky;
    top: 0;
    background: var(--primary);
    color: #fff;
    font-weight: 600;
    font-size: 13px;
    text-align: left;
    padding: 12px 14px;
    z-index: 2;
  }
  tbody td {
    padding: 11px 14px;
    font-size: 13.5px;
    border-bottom: 1px solid var(--border);
    white-space: nowrap;
  }
  tbody tr {
    animation: rowIn 0.3s ease backwards;
    transition: background 0.15s ease;
  }
  tbody tr:nth-child(even) { background: #fafbfe; }
  tbody tr:hover { background: var(--primary-light); }
  tbody tr.hidden-row { display: none; }

  .badge {
    padding: 4px 10px;
    border-radius: 999px;
    font-size: 11.5px;
    font-weight: 600;
    color: #fff;
    display: inline-block;
  }
  .green { background: var(--green); }
  .red { background: var(--red); }
  .blue { background: #2563eb; }
  .gray { background: var(--gray); }

  .toggle-btn {
    border: none;
    padding: 6px 16px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    color: #fff;
    transition: transform 0.15s ease, opacity 0.15s ease;
  }
  .toggle-btn.green { background: var(--green); }
  .toggle-btn.red { background: var(--red); }
  .toggle-btn:hover { transform: scale(1.05); opacity: 0.92; }

  /* ─── Pagination ─── */
  .pagination {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    padding: 14px;
    flex-wrap: wrap;
    border-top: 1px solid var(--border);
    background: #fbfcfe;
  }
  .pagination button {
    border: 1px solid var(--border);
    background: #fff;
    color: var(--text);
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 12.5px;
    cursor: pointer;
    transition: all 0.15s ease;
  }
  .pagination button:hover:not(:disabled) {
    background: var(--primary);
    color: #fff;
    border-color: var(--primary);
  }
  .pagination button.active {
    background: var(--primary);
    color: #fff;
    border-color: var(--primary);
    font-weight: 700;
  }
  .pagination button:disabled {
    opacity: 0.4;
    cursor: not-allowed;
  }

  .empty-state {
    padding: 30px;
    text-align: center;
    color: var(--muted);
    font-size: 14px;
  }

  footer {
    margin-top: 20px;
    text-align: center;
    color: var(--muted);
    font-size: 13px;
    animation: fadeInPage 0.6s ease;
  }

  @media (max-width: 640px) {
    body { padding: 14px; }
    .header { padding: 20px; }
    .search-box input { width: 150px; }
    .search-box input:focus { width: 180px; }
  }
</style>
</head>
<body>

<div class="header">
  <div>
    <h1><span class="live-dot"></span>&nbsp;Labour Hub Admin Panel</h1>
    <p>Real-time overview of users, jobs, industries & requests</p>
  </div>
  <div class="timestamp">Loaded: ${new Date().toLocaleString()}</div>
</div>

<div class="stats">
  <div class="stat-card"><div class="label">Total Users</div><div class="value">${users.length}</div></div>
  <div class="stat-card"><div class="label">Total Jobs</div><div class="value">${jobs.length}</div></div>
  <div class="stat-card"><div class="label">Applications</div><div class="value">${applications.length}</div></div>
  <div class="stat-card"><div class="label">Industries</div><div class="value">${industries.length}</div></div>
  <div class="stat-card"><div class="label">Borrow Requests</div><div class="value">${borrows.length}</div></div>
</div>

<!-- USERS -->
<div class="section" data-section="users">
  <div class="section-header">
    <h2>👤 Users <span class="count-badge">${users.length}</span></h2>
    <div class="search-box"><input type="text" placeholder="Search users..." class="search-input"/></div>
  </div>
  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Skills</th><th>Push Token</th><th>Created</th></tr>
      </thead>
      <tbody>
        ${users
          .map(
            (u, i) => `
        <tr style="animation-delay:${Math.min(i * 0.02, 0.4)}s" data-search="${(u.firstName + " " + u.lastName + " " + u.email + " " + u.phone + " " + u.role + " " + (u.skills || []).join(" ")).toLowerCase()}">
          <td>${u.firstName} ${u.lastName}</td>
          <td>${u.email}</td>
          <td>${u.phone}</td>
          <td><span class="badge blue">${u.role}</span></td>
          <td>${u.skills?.join(", ") || "-"}</td>
          <td><span class="badge ${u.expoPushToken ? "green" : "gray"}">${u.expoPushToken ? "✅ Yes" : "❌ No"}</span></td>
          <td>${new Date(u.createdAt).toLocaleString()}</td>
        </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  <div class="pagination"></div>
</div>

<!-- JOBS -->
<div class="section" data-section="jobs">
  <div class="section-header">
    <h2>🛠 Jobs <span class="count-badge">${jobs.length}</span></h2>
    <div class="search-box"><input type="text" placeholder="Search jobs..." class="search-input"/></div>
  </div>
  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>Title</th><th>Location</th><th>Skill</th><th>Budget</th><th>Workers</th><th>Applicants</th><th>Posted By</th></tr>
      </thead>
      <tbody>
        ${jobs
          .map(
            (j, i) => `
        <tr style="animation-delay:${Math.min(i * 0.02, 0.4)}s" data-search="${(j.title + " " + j.location + " " + j.skill + " " + (j.createdBy?.email || "")).toLowerCase()}">
          <td>${j.title}</td>
          <td>${j.location}</td>
          <td>${j.skill}</td>
          <td>${j.budget}</td>
          <td>${j.workersRequired}</td>
          <td>${j.noOfWorkersApplied || 0}</td>
          <td>${j.createdBy?.email || "-"}</td>
        </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  <div class="pagination"></div>
</div>

<!-- APPLICATIONS -->
<div class="section" data-section="applications">
  <div class="section-header">
    <h2>📄 Job Applications <span class="count-badge">${applications.length}</span></h2>
    <div class="search-box"><input type="text" placeholder="Search applications..." class="search-input"/></div>
  </div>
  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>Job ID</th><th>Contractor</th><th>Labour</th><th>Date</th></tr>
      </thead>
      <tbody>
        ${applications
          .map(
            (a, i) => `
        <tr style="animation-delay:${Math.min(i * 0.02, 0.4)}s" data-search="${(a.jobId + " " + a.contractorEmail + " " + a.labourEmail).toLowerCase()}">
          <td>${a.jobId}</td>
          <td>${a.contractorEmail}</td>
          <td>${a.labourEmail}</td>
          <td>${new Date(a.appliedAt).toLocaleString()}</td>
        </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  <div class="pagination"></div>
</div>

<!-- INDUSTRIES -->
<div class="section" data-section="industries">
  <div class="section-header">
    <h2>🏭 Industries <span class="count-badge">${industries.length}</span></h2>
    <div class="search-box"><input type="text" placeholder="Search industries..." class="search-input"/></div>
  </div>
  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>Industry</th><th>Owner</th><th>Email</th><th>Phone</th><th>Textile</th><th>Push Token</th><th>Status</th></tr>
      </thead>
      <tbody>
        ${industries
          .map(
            (ind, i) => `
        <tr style="animation-delay:${Math.min(i * 0.02, 0.4)}s" data-search="${(ind.industry + " " + ind.owner + " " + ind.email + " " + ind.textileType).toLowerCase()}">
          <td>${ind.industry}</td>
          <td>${ind.owner}</td>
          <td>${ind.email}</td>
          <td>${ind.phone}</td>
          <td>${ind.textileType}</td>
          <td><span class="badge ${ind.expoPushToken ? "green" : "gray"}">${ind.expoPushToken ? "✅ Yes" : "❌ No"}</span></td>
          <td>
            <form method="POST" action="/api/admin/industry-toggle/${ind._id}" onsubmit="return confirm('${ind.active ? "Deactivate" : "Activate"} this industry?');" style="display:inline;">
              <button type="submit" class="toggle-btn ${ind.active ? "green" : "red"}">${ind.active ? "Active" : "Inactive"}</button>
            </form>
          </td>
        </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  <div class="pagination"></div>
</div>

<!-- BORROWS -->
<div class="section" data-section="borrows">
  <div class="section-header">
    <h2>🔄 Borrow Requests <span class="count-badge">${borrows.length}</span></h2>
    <div class="search-box"><input type="text" placeholder="Search borrow requests..." class="search-input"/></div>
  </div>
  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>From</th><th>To</th><th>Labour</th><th>Skills</th><th>Location</th><th>Status</th></tr>
      </thead>
      <tbody>
        ${borrows
          .map(
            (b, i) => `
        <tr style="animation-delay:${Math.min(i * 0.02, 0.4)}s" data-search="${(b.fromIndustryEmail + " " + b.toIndustryEmail + " " + b.skills + " " + b.location).toLowerCase()}">
          <td>${b.fromIndustryEmail}</td>
          <td>${b.toIndustryEmail}</td>
          <td>${b.labourRequired}</td>
          <td>${b.skills}</td>
          <td>${b.location}</td>
          <td><span class="badge ${b.status === "Approved" ? "green" : b.status === "Rejected" ? "red" : "gray"}">${b.status}</span></td>
        </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>
  <div class="pagination"></div>
</div>

<footer>© ${new Date().getFullYear()} Labour Hub · Admin Panel</footer>

<script>
  // ─── Search + Pagination per section ───
  const ROWS_PER_PAGE = 8;

  document.querySelectorAll('.section').forEach(section => {
    const tbody = section.querySelector('tbody');
    const allRows = Array.from(tbody.querySelectorAll('tr'));
    const paginationEl = section.querySelector('.pagination');
    const searchInput = section.querySelector('.search-input');
    let filteredRows = allRows;
    let currentPage = 1;

    function renderPage() {
      const totalPages = Math.max(1, Math.ceil(filteredRows.length / ROWS_PER_PAGE));
      if (currentPage > totalPages) currentPage = totalPages;

      allRows.forEach(r => r.classList.add('hidden-row'));

      const start = (currentPage - 1) * ROWS_PER_PAGE;
      const pageRows = filteredRows.slice(start, start + ROWS_PER_PAGE);
      pageRows.forEach(r => r.classList.remove('hidden-row'));

      // empty state
      let emptyEl = tbody.querySelector('.empty-row');
      if (filteredRows.length === 0) {
        if (!emptyEl) {
          const colCount = section.querySelectorAll('thead th').length;
          const tr = document.createElement('tr');
          tr.className = 'empty-row';
          tr.innerHTML = '<td colspan="' + colCount + '" class="empty-state">No matching records found</td>';
          tbody.appendChild(tr);
        }
      } else if (emptyEl) {
        emptyEl.remove();
      }

      // build pagination controls
      paginationEl.innerHTML = '';
      if (totalPages <= 1) return;

      const prevBtn = document.createElement('button');
      prevBtn.textContent = '‹ Prev';
      prevBtn.disabled = currentPage === 1;
      prevBtn.onclick = () => { currentPage--; renderPage(); };
      paginationEl.appendChild(prevBtn);

      const maxButtons = 5;
      let startPage = Math.max(1, currentPage - Math.floor(maxButtons / 2));
      let endPage = Math.min(totalPages, startPage + maxButtons - 1);
      startPage = Math.max(1, endPage - maxButtons + 1);

      for (let p = startPage; p <= endPage; p++) {
        const btn = document.createElement('button');
        btn.textContent = p;
        if (p === currentPage) btn.classList.add('active');
        btn.onclick = () => { currentPage = p; renderPage(); };
        paginationEl.appendChild(btn);
      }

      const nextBtn = document.createElement('button');
      nextBtn.textContent = 'Next ›';
      nextBtn.disabled = currentPage === totalPages;
      nextBtn.onclick = () => { currentPage++; renderPage(); };
      paginationEl.appendChild(nextBtn);
    }

    if (searchInput) {
      searchInput.addEventListener('input', () => {
        const q = searchInput.value.trim().toLowerCase();
        filteredRows = allRows.filter(r => (r.dataset.search || '').includes(q));
        currentPage = 1;
        renderPage();
      });
    }

    renderPage();
  });
</script>

</body>
</html>`;

    res.send(html);
  } catch (err) {
    console.error(err);
    res.status(500).send("Server Error");
  }
});

// ── Send Agreement Email
app.post("/api/send-agreement-email", async (req, res) => {
  try {
    const {
      fromCompany,
      toCompany,
      partyType,
      description,
      fromEmail,
      toEmail,
    } = req.body;

    if (!fromEmail || !toEmail) {
      return res.status(400).json({ error: "Both emails are required" });
    }

    const date = new Date().toLocaleDateString();

    const agreementHTML = (recipientLabel) => `
      <div style="font-family:'Segoe UI',sans-serif;background:#f5f7fa;padding:40px 0;">
        <div style="max-width:700px;background:#fff;margin:0 auto;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
          <div style="background:#1e3a8a;padding:25px 20px;text-align:center;">
            <h1 style="color:#fff;margin:0;">LABOUR HUB</h1>
            <p style="color:#bfdbfe;margin-top:6px;">Official Labour & Contractor Agreement</p>
          </div>
          <div style="padding:30px 25px;color:#1f2937;">
            <p>Dear <strong>${recipientLabel}</strong>,<br>Please find below your digitally generated agreement.</p>
            <div style="background:#f0f4ff;padding:20px;border-radius:8px;margin:20px 0;border:1px solid #c7d2fe;">
              <p><strong>From Company:</strong> ${fromCompany}</p>
              <p><strong>To Company:</strong> ${toCompany}</p>
              <p><strong>Agreement Type:</strong> ${partyType}</p>
              <p><strong>Date:</strong> ${date}</p>
            </div>
            <h3 style="color:#1e3a8a;">1. Scope of Work</h3>
            <p>${description}</p>
            <h3 style="color:#1e3a8a;">2. Responsibilities</h3>
            <p>The service provider shall comply with labour laws, safety policies, and professional conduct requirements.</p>
            <h3 style="color:#1e3a8a;">3. Payment Terms</h3>
            <p>Payments shall be processed as mutually agreed. Labour Hub holds no responsibility for payment disputes.</p>
            <h3 style="color:#1e3a8a;">4. Confidentiality</h3>
            <p>All business and operational information shall remain strictly confidential.</p>
            <h3 style="color:#1e3a8a;">5. Termination</h3>
            <p>Either party may terminate this agreement with written notice upon violation of terms.</p>
            <h3 style="color:#1e3a8a;">6. Governing Law</h3>
            <p>This agreement shall be governed under the laws of Pakistan.</p>
            <h3 style="color:#1e3a8a;">7. Digital Acceptance</h3>
            <p>This document is legally binding upon digital confirmation.</p>
            <div style="margin-top:30px;padding-top:20px;border-top:1px solid #e5e7eb;">
              <p><strong>Labour Hub</strong><br>Email: fyplabourhub@gmail.com<br>Contact: 0334-112212<br>Date: ${date}<br>Digitally Generated Contract</p>
            </div>
          </div>
          <div style="background:#f0f2f5;text-align:center;padding:20px;">
            <p style="color:#777;font-size:13px;margin:0;">© ${new Date().getFullYear()} Labour Hub · Pakistan</p>
          </div>
        </div>
      </div>
    `;

    const [result1, result2] = await Promise.all([
      sendSingleEmail(
        fromEmail,
        `Labour Hub – Agreement with ${toCompany}`,
        agreementHTML(fromCompany),
      ),
      sendSingleEmail(
        toEmail,
        `Labour Hub – Agreement with ${fromCompany}`,
        agreementHTML(toCompany),
      ),
    ]);

    if (result1 && result2) {
      return res.status(200).json({
        success: true,
        message: "Agreement emails sent to both parties.",
      });
    } else {
      return res.status(500).json({
        success: false,
        message: "One or both emails failed to send.",
      });
    }
  } catch (err) {
    console.error("Agreement email error:", err);
    res.status(500).json({ error: "Server error sending agreement emails." });
  }
});

// ─── DB connect ───────────────────────────────────────────────────────────────
async function start() {
  if (!process.env.MONGO_URI) {
    console.error("MONGO_URI missing in .env");
    process.exit(1);
  }
  if (!process.env.JWT_SECRET) {
    console.error("JWT_SECRET missing in .env");
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("Connected to MongoDB");
  } catch (err) {
    console.error("Failed to connect to MongoDB:", err);
    process.exit(1);
  }
}

start();

app.get("/", (req, res) => res.send("🚀 Labour Hub APIs are running!"));

const port = process.env.PORT || 3000;
app.listen(port, () =>
  console.log(`✅ Server running at http://localhost:${port}`),
);
